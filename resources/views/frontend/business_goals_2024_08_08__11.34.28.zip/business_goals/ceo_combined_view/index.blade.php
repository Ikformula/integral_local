@extends('frontend.layouts.app')

@section('title', 'Business Areas')

@section('content')
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col">
                <form action="" method="GET">
                        <div class="row">
                            <div class="col-10">
                                <div class="form-group mb-0">
                                    <select class="form-control" name="week_range_id">
                                        @php $week_id = isset($week_range_id) ? $week_range_id : null;
                                        @endphp
                                        <option value="{{ $week_in_focus->id }}">Wk {{ $week_in_focus->week_number }}: {{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }}</option>
                                        @include('frontend.business_goals.parts._week_range_options', ['selected_week_id' => $week_id])
                                    </select>
                                    <label>Week Selection</label>
                                </div>
                            </div>
                            <div class="col-2">
                                <button type="submit" class="btn bg-navy btn-block">Filter</button>
                            </div>
                        </div>
                    </form>
            </div>
        </div>

{{--        <div class="card-columns">--}}
        <div class="row">
            @foreach($custom_order as $order)
{{--            @foreach($accessible_business_areas as $key => $business_area)--}}
                @php
                    $business_area = $accessible_business_areas[$order];
                        $business_area_id = $business_area->id;
                        $presentation_data = $multi_presentation_data[$business_area->id];
                        $form_fields = $multi_form_fields[$business_area->id];
                        $form_fields_collection = $multi_form_fields_collection[$business_area->id];
                @endphp
                <div class="col{{ count($accessible_business_areas) > 1 ? '-md-6' : ''  }}">
                    <div class="card arik-card">
                        <div class="card-body" style="height: 700px; overflow: scroll;">
                            @include('frontend.business_goals.quadrants._'.$business_area_id)
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
