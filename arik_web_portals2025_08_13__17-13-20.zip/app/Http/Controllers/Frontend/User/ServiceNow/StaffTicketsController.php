<?php

namespace App\Http\Controllers\Frontend\User\ServiceNow;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StaffTicketsController extends Controller
{
    public function index()
    {

    }
}
