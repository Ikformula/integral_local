@extends('frontend.layouts.app')

@section('title', 'Staff Travel bookings' )

@push('after-styles')
    @include('includes.partials._datatables-css')
@endpush


@section('content')

    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body table-responsive">
                            @include('frontend.staff_travel._bookings_table')
                        </div>
                        <div class="card-footer">
                            {{ $staff_travel_bookings->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('after-scripts')
    @include('includes.partials._datatables-js')
    <script>
        $(".table").DataTable({
            "responsive": false, "lengthChange": false, "autoWidth": true, paging: false, scrollY: 465,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('.table_wrapper .col-md-6:eq(0)');
    </script>
@endpush
