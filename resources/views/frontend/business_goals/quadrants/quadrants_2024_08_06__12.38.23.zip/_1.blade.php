
{{--People & Organisational Development--}}
@include('frontend.business_goals.parts.table2xlsx_button', ['table_id' => 'ba_'. $business_area_id] )
<table class="table table-hover table-sm" id="ba_{{ $business_area_id }}">
    <thead class="bg-secondary">
    <tr>
        <th colspan="5" class="bg-navy">{{ $business_area->name }}  Report</th>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>Wk {{ $week_in_focus->week_number }} <small>({{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }}) </td>
        <td>Previous Wk ({{ $week_in_focus->week_number - 1 }})<small>({{ $presentation_data['titles']['last week'] }})</small></td>
        <td>Previous Mth <small>({{ $presentation_data['titles']['last month'] }})</small></td>
    </tr>
    </thead>
    @php
        $headcount = findFirstArrayWithValue($form_fields, 'Headcount')['id'];
/*
$cycleTimeTarget = findFirstArrayWithValue($form_fields, 'Cycle Time (Target)')['id'];
$cycleTimeActual = findFirstArrayWithValue($form_fields, 'Cycle Time (Actual)')['id'];
$costPerHire1Target = findFirstArrayWithValue($form_fields, 'Cost per Hire (1) Target')['id'];
$costPerHire1Actual = findFirstArrayWithValue($form_fields, 'Cost per Hire (1) Actual')['id'];
$avgEmployeeTenureYrsTarget = findFirstArrayWithValue($form_fields, 'Average Employee Tenure (Yrs) Target')['id'];
$avgEmployeeTenureYrsActual = findFirstArrayWithValue($form_fields, 'Average Employee Tenure (Yrs) Actual')['id'];
*/
$longTermIllness = findFirstArrayWithValue($form_fields, 'Long term illness')['id'];
$totalStaffPositive = findFirstArrayWithValue($form_fields, 'Total Number of Staff tested positive (Drugs and Alcohol)')['id'];
$totalStaffTested = findFirstArrayWithValue($form_fields, 'Total Number of Staff tested (Drugs and Alcohol)')['id'];

    $LOA = findFirstArrayWithValue($form_fields, 'LOA')['id'];
    $permanent_staff = findFirstArrayWithValue($form_fields, 'Permanent Staff')['id'];
    $contract = findFirstArrayWithValue($form_fields, 'Contract Staff')['id'];
    $NYSC = findFirstArrayWithValue($form_fields, 'NYSC')['id'];
    $Interns = findFirstArrayWithValue($form_fields, 'Interns')['id'];
    $exits = findFirstArrayWithValue($form_fields, 'Exit')['id'];
    @endphp
    <tbody>
    <tr>
        <th>Headcount</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$headcount]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$headcount]['total'] ?? 'N/A'}}</td>
{{--         <td>{{ $presentation_data['previous_month'][$headcount]['total'] ?? 'N/A'}}</td>  --}}
    </tr>
    <tr>
        <th>Permanent Staff</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$permanent_staff]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$permanent_staff]['total'] ?? 'N/A'}}</td>
{{--         <td>{{ $presentation_data['previous_month'][$permanent_staff]['total'] ?? 'N/A'}}</td>  --}}
    </tr>
    <tr>
        <th>Contract Staff</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$contract]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$contract]['total'] ?? 'N/A'}}</td>
{{--         <td>{{ $presentation_data['previous_month'][$contract]['total'] ?? 'N/A'}}</td>  --}}
    </tr>
    <tr>
        <th>Interns</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$Interns]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$Interns]['total'] ?? 'N/A'}}</td>
{{--         <td>{{ $presentation_data['previous_month'][$Interns]['total'] ?? 'N/A'}}</td>  --}}
    </tr>
    <tr>
        <th>NYSC</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$NYSC]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$NYSC]['total'] ?? 'N/A'}}</td>
{{--         <td>{{ $presentation_data['previous_month'][$NYSC]['total'] ?? 'N/A'}}</td>  --}}
    </tr>
    <tr>
        <th>LOA</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$LOA]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$LOA]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_month'][$LOA]['total'] ?? 'N/A'}}</td>
    </tr>
    <tr>
        <th>Exits</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$exits]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$exits]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_month'][$exits]['total'] ?? 'N/A'}}</td>
    </tr>
{{--    <tr>--}}
{{--        <th>Cycle Time</th>--}}
{{--        <td>{{ $presentation_data['current_week'][$cycleTimeTarget]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['current_week'][$cycleTimeActual]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_week'][$cycleTimeActual]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_month'][$cycleTimeActual]['total'] ?? 'N/A'}}</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>Cost per Hire (1)</th>--}}
{{--        <td>{{ $presentation_data['current_week'][$costPerHire1Target]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['current_week'][$costPerHire1Actual]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_week'][$costPerHire1Actual]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_month'][$costPerHire1Actual]['total'] ?? 'N/A'}}</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>Average Employee Tenure (Yrs)</th>--}}
{{--        <td>{{ $presentation_data['current_week'][$avgEmployeeTenureYrsTarget]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['current_week'][$avgEmployeeTenureYrsActual]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_week'][$avgEmployeeTenureYrsActual]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_month'][$avgEmployeeTenureYrsActual]['total'] ?? 'N/A'}}</td>--}}
{{--    </tr>--}}
    <tr>
        <th>Long term illness</th>
        <td></td>
        <td>{{ $presentation_data['current_week'][$longTermIllness]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$longTermIllness]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_month'][$longTermIllness]['total'] ?? 'N/A'}}</td>
    </tr>

    <tr>
        <th colspan="5">Drugs & Alcohol</th>
    </tr>
    <tr>
        <td>Total Number of Staff tested positive</td>
        <td></td>
        <td>{{ $presentation_data['current_week'][$totalStaffPositive]['total'] ?? 'N/A'}}</td>
    </tr>
    <tr>
        <td>Total Number of Staff tested </td>
        <td></td>
        <td>{{ $presentation_data['current_week'][$totalStaffTested]['total'] ?? 'N/A'}}</td>
    </tr>
    </tbody>
</table>
