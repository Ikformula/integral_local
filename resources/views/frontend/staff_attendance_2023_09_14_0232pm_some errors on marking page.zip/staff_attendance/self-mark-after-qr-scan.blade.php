@extends('frontend.staff_attendance.mark-attendance-layout')

@section('content')
    <div class="row">
    <div class="col">
        <h4 class="card-title">Arik Air Staff Details</h4>
        <div class="row">
            <div class="col mb-4">
                <ul class="list-group" id="attendance_list_group">
                </ul>
            </div>
        </div>
    <form id="check_staff_info">
        @csrf
        <input type="hidden" name="operator_user_id" value="{{ auth()->id() }}">
        <div class="my-2">
            <label for="staff_ara_id">ARA Number</label><br>
            <small class="text-info">You can now check for contract staff with letters in their ARA IDs e.g 8021c</small>
            <div class="input-group">
                <button class="btn btn-outline-danger" type="reset" id="clear-button">x</button>
                <input type="text" name="staff_ara_id" id="staff_ara_id" minlength="4" class="form-control" autofocus placeholder="1066">
                <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Check</button>
            </div>
            <small class="text-muted">Enter ARA number only</small>
        </div>
    </form>

    <form id="attendance_form">
        @csrf
        <input type="hidden" id="ara_id" name="staff_ara_id">

        <div class="form-group" id="temperature" style="display: none;">
            <label>Temperature</label>
            <input type="number" name="temperature" id="temperature_field" class="form-control">
        </div>

        <div class="form-group">
            <button type="button" id="attendance_button" class="btn btn-block btn-danger disabled">
                Mark Attendance
            </button>
        </div>
    </form>

    </div>

    <div class="col mb-3" style="display: none" id="id_card_row">
        <div id="staff_details"></div>
        <img src="..." class="img-fluid rounded mx-auto d-block" alt="..." id="id_card">
    </div>
    </div>
@endsection
