<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\CallCenterLog;
use App\Models\Setting;
use App\Models\StaffTravelBooking;
use Carbon\Carbon;
use Illuminate\Http\Request;

class StaffTravelController extends Controller
{
    public function index()
    {
        $staff_travel_bookings = StaffTravelBooking::latest()->take(10)->get();
        return view('frontend.staff_travel.index', compact('staff_travel_bookings'));
    }

    public function bookings()
    {
        $staff_travel_bookings = StaffTravelBooking::latest()->paginate();
        return view('frontend.staff_travel.bookings', compact('staff_travel_bookings'));
    }

    public function routeForFailure($msg)
    {
        return redirect()->route('frontend.index')->withErrors($msg);
    }

    public function staffTravelPortal()
    {
        $auth_user = auth()->user();
        $staff_member = $auth_user->staff_member;
        if(!isset($staff_member))
            return $this->routeForFailure('Not a staff member');

        $yearly_booking_allowance = Setting::where('category', 'staff_travel_portal')
            ->where('key', 'yearly_booking_allowance')
            ->first();

        $now = Carbon::now();
        $staff_ara_id = $staff_member->staff_ara_id;
        $years_bookings = StaffTravelBooking::where('staff_ara_id', $staff_ara_id)
            ->where('request_year', $now->year)
            ->get();
        $years_bookings_count = $years_bookings->sum('adult') + $years_bookings->sum('child');

        $stats['Bookings This Year'] = [
          'title' => 'Bookings This Year',
            'value' => $years_bookings_count,
            'icon' => 'book-open'
        ];

        $stats['Bookings Left']['title'] = 'Bookings Left for This Year';

        $stats['Bookings Left']['value'] = $yearly_booking_allowance->value - $stats['Bookings This Year']['value'];
        $stats['Bookings Left']['icon'] = 'book-open';

        $staff_travel_bookings = StaffTravelBooking::where('staff_ara_id', $staff_ara_id)->take(10)->get();

        return view('frontend.staff_travel.staff_travel_portal')->with([
            'stats' => $stats,
            'staff_travel_bookings' => $staff_travel_bookings
        ]);
    }

    public function myBookings()
    {
        $auth_user = auth()->user();
        $staff_member = $auth_user->staff_member;
        if(!isset($staff_member))
            return $this->routeForFailure('Not a staff member');

        $staff_travel_bookings = StaffTravelBooking::where('staff_ara_id', $staff_member->staff_ara_id)->latest()->paginate();
        return view('frontend.staff_travel.bookings', compact('staff_travel_bookings'));
    }

    public function makeBooking()
    {
        $tomorrow = Carbon::tomorrow();
        return view('frontend.staff_travel.make_booking')->with([
            'tomorrow' => $tomorrow
        ]);
    }

    public function processBooking()
    {

    }


}
