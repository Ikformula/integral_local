@extends('frontend.layouts.app')

@section('title', 'Staff Travel Dashboard' )

@push('after-styles')

@endpush

@section('content')

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                @foreach($stats as $stat)
                    <div class="col-md-4">
                        @component('frontend.components.dashboard_stat_widget', ['icon' => $stat['icon'], 'title' => $stat['title']])
                            {{ $stat['value'] }}
                        @endcomponent
                    </div>
                @endforeach
            </div>

            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Staff ARA ID</th>
                                    <th>Username</th>
                                    <th>Request Date</th>
                                    <th>Request Time</th>
                                    <th>Departure</th>
                                    <th>Returns</th>
                                    <th>Adult</th>
                                    <th>Child</th>
                                    <th>Infant</th>
                                    <th>PNR</th>
                                    <th>IP Address</th>
                                    <th>Comp Name</th>
                                    <th>Transaction ID</th>
                                    <th>Created At</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($staff_travel_bookings as $booking)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $booking->staff_ara_id }}</td>
                                        <td>{{ $booking->username }}</td>
                                        <td>{{ $booking->request_date }}</td>
                                        <td>{{ $booking->request_time }}</td>
                                        <td>{{ $booking->departure }}</td>
                                        <td>{{ $booking->returns }}</td>
                                        <td>{{ $booking->adult }}</td>
                                        <td>{{ $booking->child }}</td>
                                        <td>{{ $booking->infant }}</td>
                                        <td>{{ $booking->pnr }}</td>
                                        <td>{{ $booking->ip_address }}</td>
                                        <td>{{ $booking->comp_name }}</td>
                                        <td>{{ $booking->transaction_id }}</td>
                                        <td>{{ $booking->created_at }}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
