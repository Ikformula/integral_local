<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\Auth\User;
use App\Models\EcsClient;
use App\Models\EcsReconciliation;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use App\Http\Controllers\Traits\EcsClientTransactionsTrait;

class EcsInternalDashController extends Controller
{
    use EcsClientTransactionsTrait;

    public function index(Request $request)
    {
        $request->validate([
           'from_date' => ['date', 'before:tomorrow'],
           'to_date' => ['date', 'after_or_equal:from_date']
        ]);
        $permission = Permission::where('name', 'manage ecs processes')->first();
        $agents = User::where('id', 1)->get();
        if($permission)
            $agents = $permission->users;
        $clients = EcsClient::all();

        $params = $request->toArray();
        $sales = $this->totalSalesStat($params);
        $numbers = $this->numSummaries($params);

        $stats_sales = ['total_credit', 'total_debit'];
        $stats_numbers = ['total_approved', 'total_pending', 'total_disputed'];

        $reconciliations = EcsReconciliation::latest()->take(5)->get();

        return view('frontend.ecs_internal.index', compact('agents', 'clients', 'sales', 'numbers', 'stats_numbers', 'stats_sales', 'reconciliations', 'params'));
    }

}
