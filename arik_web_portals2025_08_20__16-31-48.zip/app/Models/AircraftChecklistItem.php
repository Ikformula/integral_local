<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AircraftChecklistItem extends Model
{
    protected $table = 'aircraft_status_checklist_items';
}
