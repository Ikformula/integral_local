<div><button class="btn btn-sm btn-primary btn-update">Update</button> <button class="btn btn-sm btn-danger btn-delete">Delete</button></div>
