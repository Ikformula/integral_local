@php $colours = [
    'navy',
    'maroon',
    // 'info',
    'danger',
    // 'warning',
    // 'success'
];
@endphp
<div class="info-box shadow">
    <span class="info-box-icon bg-{{ isset($colour) ? $colour : $colours[array_rand($colours)] }}"><i class="fas fa-{{ $icon ?? 'poll' }}"></i></span>

    <div class="info-box-content">
        <span class="info-box-text">{{ $title }}</span>
        <span class="info-box-number">{{ $slot }}</span>
    </div>
    <!-- /.info-box-content -->
</div>
<!-- /.info-box -->

{{--<div class="small-box bg-{{ $colours[array_rand($colours)] }}">--}}
{{--    <div class="inner">--}}
{{--        <h3>{{ $slot }}</h3>--}}

{{--        <p>{{ $title }}</p>--}}
{{--    </div>--}}
{{--    <div class="icon">--}}
{{--        <i class="fas fa-{{ $icon ?? 'poll' }}"></i>--}}
{{--    </div>--}}
{{--</div>--}}
