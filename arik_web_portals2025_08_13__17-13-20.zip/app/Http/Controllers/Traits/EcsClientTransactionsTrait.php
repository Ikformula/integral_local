<?php


namespace App\Http\Controllers\Traits;


use App\Models\EcsClient;
use App\Models\EcsClientAccountSummary;
use Illuminate\Http\Request;

trait EcsClientTransactionsTrait
{
    public function addTransactionSummary(EcsClient $client, $amount, $details = '', $type = 'credit', $ticket_number = null)
    {
        $summary = new EcsClientAccountSummary();
        if($type == 'credit'){
            $summary->credit_amount = $amount;
            $working_amount = $amount;
        } else {
            $summary->debit_amount = $amount;
            $working_amount = -1 * $amount;
        }

        $summary->details = $details;
        $new_balance = $client->current_balance + $working_amount;
        $summary->balance = $new_balance;
        $summary->client_id = $client->id;
        $summary->ticket_number = $ticket_number;
        $summary->agent_user_id = auth()->id();
        $summary->save();
        $client->current_balance = $new_balance;
        $client->save();
    }

    public function addDisputeMessage(EcsClientAccountSummary $summary, $msg = '')
    {
        if($msg == '' || is_null($msg))
            return false;

        $sender = auth()->user();
        $current_messages = $summary->messages;
        if(!empty($current_messages) && checkIsJson($current_messages)) {
            $current_messages_arr = json_decode($current_messages);
        }else{
            $current_messages_arr = [];
        }

            $current_messages_arr[] = [
                'sender_id' => $sender->id,
                'sender_name' => $sender->full_name,
                'sent_at' => now(),
                'sent_at_human' => now()->toDayDateTimeString(),
                'message' => $msg,
                'summary_id' => $summary->id
            ];

        $summary->messages = json_encode($current_messages_arr);
        $summary->save();

        return true;
    }

    public function totalSalesStat($params = [])
    {
        // Code for getting total sales statistics
        $query = EcsClientAccountSummary::query();
        if(isset($params['client_id']) && !empty($params['client_id'])) {
            $query->where('client_id', $params['client_id']);
        }
        if(isset($params['from_date']) && !empty($params['from_date'])) {
            $query->whereDate('created_at', '>=', $params['from_date']);
        }
        if(isset($params['to_date']) && !empty($params['to_date'])) {
            $query->whereDate('created_at', '<=', $params['to_date']);
        }
        if (isset($params['agent_user_id']) && !empty($params['agent_user_id'])) {
            $query->where('agent_user_id', $params['agent_user_id']);
        }

        $totalCredit = $query->sum('credit_amount');
        $totalDebit = $query->sum('debit_amount');
//        $totalBalance = $query->sum('balance');

        return [
            'total_credit' => $totalCredit,
            'total_debit' => $totalDebit,
//            'total_balance' => $totalBalance,
            'params' => $params
        ];
    }

    public function numSummaries($params = [])
    {
        // Code for getting total sales statistics
        $query = EcsClientAccountSummary::query();
        if(isset($params['client_id']) && !empty($params['client_id'])) {
            $query->where('client_id', $params['client_id']);
        }
        if(isset($params['from_date']) && !empty($params['from_date'])) {
            $query->whereDate('created_at', '>=', $params['from_date']);
        }
        if(isset($params['to_date']) && !empty($params['to_date'])) {
            $query->whereDate('created_at', '<=', $params['to_date']);
        }
        if (isset($params['agent_user_id']) && !empty($params['agent_user_id'])) {
            $query->where('agent_user_id', $params['agent_user_id']);
        }

        $approvedQuery = clone $query;
        $unapprovedQuery = clone $query;

        $numApproved = $approvedQuery->whereNotNull('client_approved_at')->count();
        $numPending = $unapprovedQuery->whereNull('client_approved_at')->whereNull('client_disputed_at')->count();
        $numDisputed = $query->whereNotNull('client_disputed_at')->whereNull('client_approved_at')->count();

        return [
            'total_approved' => $numApproved,
            'total_pending' => $numPending,
            'total_disputed' => $numDisputed,
            'params' => $params
        ];
    }


}
