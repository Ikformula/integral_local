<input type="text" name="phone_model" class="form-control" value="{{ $phone_model }}">
