@extends('frontend.layouts.app')

@section('title', 'ACFA Report')

@section('content')
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
<div class="card">
  <div class="card-body">

  </div>
</div>
                </div>
            </div>
        </div>
    </section>
@endsection
