{{-- Aircraft Status - Daily input --}}
@include('frontend.business_goals.quadrants._11')
