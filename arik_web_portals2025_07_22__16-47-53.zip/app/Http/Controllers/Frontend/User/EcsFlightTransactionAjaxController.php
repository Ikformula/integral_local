<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\EcsFlightTransaction;
use Illuminate\Http\Request;

class EcsFlightTransactionAjaxController extends Controller
{
    public function index()
    {
        $ecs_flight_transactions = EcsFlightTransaction::with([
            'ecs_booking_idRelation',
            'client_idRelation',
            'client_approver_idRelation',
        ])->get();

        return view('frontend.ecs_flight_transactions.index', compact('ecs_flight_transactions'));
    }

    public function store(Request $request)
    {
        EcsFlightTransaction::create($request->all());
        return back()->withFlashSuccess('Flight Transaction created successfully.');
    }

    public function update(Request $request, $id)
    {
        $ecs_flight_transactions = EcsFlightTransaction::findOrFail($id);
        $ecs_flight_transactions->update($request->all());
        return back()->withFlashSuccess('Flight Transaction updated successfully.');
    }

    public function destroy($id)
    {
        EcsFlightTransaction::destroy($id);
        return back()->withFlashSuccess('Flight Transaction deleted successfully.');
    }
}
