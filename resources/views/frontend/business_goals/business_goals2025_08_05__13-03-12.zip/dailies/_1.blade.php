
{{--People & Organisational Development--}}
@include('frontend.business_goals.dailies._table')
