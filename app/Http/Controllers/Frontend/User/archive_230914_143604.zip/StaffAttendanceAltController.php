<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\ManagerAbsenceLatenessAuthorization;
use App\Models\StaffAttendance;
use App\Models\StaffMember;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StaffAttendanceAltController extends Controller
{
    public function index()
    {
        $todays_attendances = StaffAttendance::select(['direction', 'created_at'])->whereDate('created_at', Carbon::today())->get();
        $stats['ins'] = $todays_attendances->where('direction', 'in')->count();
        $stats['outs'] = $todays_attendances->where('direction', 'out')->count();
        $stats['on_prem'] = $stats['ins'] - $stats['outs'];

//        dd($stats);
        return view('frontend.staff_attendance.index')->with([
            'stats' => $stats
        ]);
    }

    public function fetchStaffAttendanceE(Request $request)
    {
        // Retrieve the start and end dates from the request
        if($request->filled('from_date')){
            $startDate = Carbon::parse($request->from_date);
        }else{
            $startDate = Carbon::now()->startOfMonth();
        }

        if($request->filled('to_date')){
            $endDate = Carbon::parse($request->to_date);
        }else{
            $endDate = Carbon::now();
        }

        // Fetch all staff members
        $staffMembers = StaffMember::all();

        // Initialize an array to store the attendance data
        $attendanceData = [];

        foreach ($staffMembers as $staffMember) {
            // Fetch the attendance records for the staff member within the date range
            $query = StaffAttendance::where('staff_ara_id', $staffMember->staff_ara_id)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->orderBy('created_at');

            // If "filter_late" field is passed and set to true, fetch only staff members who were late at least once
            if ($request->filled('filter_late') && $request->boolean('filter_late')) {
                $query->where('direction', 'in')
                    ->where('hour', '>=', 9);
            }

            $attendances = $query->get();


            // Initialize an array to store the attendance data for the staff member
            $staffAttendanceData = [
                'serial_number' => $staffMember->id,
                'name' => $staffMember->other_names . ' ' . $staffMember->surname,
                'staff_ara_id' => $staffMember->staff_ara_id,
            ];

            // Iterate through the attendance records and populate the attendance data array
            foreach ($attendances as $attendance) {
                $date = $attendance->created_at->toDateString();
                $direction = $attendance->direction;

                // Check if the date exists in the attendance data array, if not, create it
                if (!isset($staffAttendanceData[$date])) {
                    $staffAttendanceData[$date] = [];
                }

                // Store the direction (in/out) for the date
                $staffAttendanceData[$date]['direction'] = $direction;

                // Store the time (hour:minutes) for the date based on the direction
                if ($direction === 'in') {
                    $staffAttendanceData[$date]['time_in'] = $attendance->hour . ':' . $attendance->minutes;
                } elseif ($direction === 'out') {
                    $staffAttendanceData[$date]['time_out'] = $attendance->hour . ':' . $attendance->minutes;
                }
            }

            // If "filter_late" field is passed and set to true, check if the staff member was late at least once
            if ($request->filled('filter_late') && $request->boolean('filter_late') && !empty($staffAttendanceData)) {
                $attendanceData[] = $staffAttendanceData;
            } elseif (!$request->filled('filter_late')) {
                // If "filter_late" field is not passed, add the staff member's attendance data to the main attendance data array
                $attendanceData[] = $staffAttendanceData;
            }
        }

//        return $attendanceData;
        // Pass the attendance data to the view and display the HTML table
        return view('frontend.staff_attendance.all_staff_attendance')->with([
            'attendanceData' => $attendanceData,
            'from_date' => $startDate,
            'to_date' => $endDate
        ]);
    }

    public function fetchStaffAttendance(Request $request)
    {
        $auth_user = auth()->user();
        // Retrieve the start and end dates from the request
        if ($request->filled('from_date')) {
            $from_date = Carbon::parse($request->from_date);
        } else {
            $from_date = Carbon::now()->startOfMonth();
        }

        $from_date_temp = $from_date->copy();
        $from_date_temp_2 = $from_date->copy();

        if($request->filled('to_date')){
            $to_date = Carbon::parse($request->to_date);
        } else {
            $to_date = Carbon::now();
        }

        $to_date_temp_2 = $to_date->copy();
        $dates = [];
        // form a dates array to use in the view
        for($date = $from_date_temp; $date <= $to_date; $date->addDay()){
            $temp_date = $date->copy();
            $dates[] = ['str' => $date->toDateString(), 'week_day' => $temp_date->dayName];
        }

        $staff_ara_id = $request->staff_ara_id;
        $department = $request->department;
        $staff_name = $request->staff_name;
        $auth_perm = 0;
        $per_page = 300;
        if($auth_user->can('manage all staff attendance')){
            $auth_perm = 1;
            $staffMembers = StaffMember::select(['surname', 'other_names', 'staff_ara_id', 'department_name'])
                ->when($staff_ara_id, function ($query, $staff_ara_id) {
                    return $query->where('staff_ara_id', $staff_ara_id);
                })
                ->when($department, function ($query, $department) {
                    return $query->where('department_name', 'LIKE', '%'.$department.'%')->orWhere('department_name_2', 'LIKE', '%'.$department.'%');
                })
                ->when($staff_name, function ($query, $staff_name) {
                    $search_words = explode(' ', $staff_name);
                    foreach ($search_words as $word) {
                        $query->where(function ($query) use ($word) {
                            $query->where('surname', 'LIKE', '%' . $word . '%')
                                ->orWhere('other_names', 'LIKE', '%' . $word . '%');
                        });
                    }
                    return $query;
                })->orderBy('staff_ara_id', 'ASC')
//                ->take(2)
                ->paginate($per_page);

        }else if($auth_user->can('manage own unit info')){
            $staffMembers = StaffMember::select(['surname', 'other_names', 'staff_ara_id', 'department_name'])
                ->where('department_name', $auth_user->department_name)
                ->orderBy('staff_ara_id', 'ASC')
                ->paginate($per_page);
        }else{
            $staffMembers = StaffMember::select(['surname', 'other_names', 'staff_ara_id', 'department_name'])->where('email', $auth_user->email)
                ->orderBy('staff_ara_id', 'ASC')
                ->paginate($per_page);
        }

        if(!$staffMembers->count())
            return redirect()->route('frontend.user.dashboard')->withErrors('No records found');


        // Initialize an array to store the attendance data
        unset($attendanceData);
        $attendanceData = [];

        foreach ($staffMembers as $staffMember) {
            $staff_ara_id = $staffMember->staff_ara_id;
            $staffAttendances[$staff_ara_id] = StaffAttendance::where('staff_ara_id', $staff_ara_id)->whereBetween('created_at', [$from_date_temp_2, $to_date_temp_2->addDay()])->get();
            $attendanceEmailLogs = DB::table('attendance_email_logs')
                ->where('staff_ara_id', $staff_ara_id)
                ->whereIn('type', ['lateness', 'absence'])
                ->orderBy('created_at', 'DESC')
                ->get();

            if(!is_null($attendanceEmailLogs)){
                $attendances[$staff_ara_id]['lateness']['last'] = $attendanceEmailLogs->where('type','lateness')->first();
                $attendances[$staff_ara_id]['lateness']['emails_count'] = $attendanceEmailLogs->where('type','lateness')->count();
                $attendances[$staff_ara_id]['absence']['last'] = $attendanceEmailLogs->where('type','absence')->first();
                $attendances[$staff_ara_id]['absence']['emails_count'] = $attendanceEmailLogs->where('type','absence')->count();
            }else{
                $attendances[$staff_ara_id]['lateness']['last'] = null;
                $attendances[$staff_ara_id]['lateness']['emails_count'] = 0;
                $attendances[$staff_ara_id]['absence']['last'] = null;
                $attendances[$staff_ara_id]['absence']['emails_count'] = 0;
            }


            if(!is_null($attendances[$staff_ara_id]['lateness']['last'])){
                $tym = Carbon::parse($attendances[$staff_ara_id]['lateness']['last']->created_at);
                $attendances[$staff_ara_id]['lateness']['last'] = $tym->diffForHumans();
            }else{
                $attendances[$staff_ara_id]['lateness']['last'] = 'none';
            }

            if(!is_null($attendances[$staff_ara_id]['absence']['last'])){
                $tym = Carbon::parse($attendances[$staff_ara_id]['absence']['last']->created_at);
                $attendances[$staff_ara_id]['absence']['last'] = $tym->diffForHumans();
            }else{
                $attendances[$staff_ara_id]['absence']['last'] = 'none';
            }

            $schedule[$staff_ara_id] = DB::table('staff_remote_schedules')
                ->where('staff_ara_id', $staff_ara_id)
                ->get();

            $authorizations[$staff_ara_id] = ManagerAbsenceLatenessAuthorization::where('staff_ara_id', $staff_ara_id)->get();
            foreach($dates as $date){

                $date_string = $date['str'];
                $date_day = $date['week_day'];

                $attendances[$staff_ara_id][$date_string]['movements'] = $staffAttendances[$staff_ara_id]->whereBetween('created_at', [$date_string.' 00:00:00', $date_string.' 23:59:59']);
                $attendances[$staff_ara_id][$date_string]['hours on prem'] = 0;

                $count_attendance[$staff_ara_id][$date_string] = isset($attendances[$staff_ara_id][$date_string]['movements']) ? count($attendances[$staff_ara_id][$date_string]['movements']) : 0;
                if($count_attendance[$staff_ara_id][$date_string] >= 1) {
                    $first_in = $attendances[$staff_ara_id][$date_string]['movements']
                        ->where('direction', 'in')
                        ->sortBy('id')
                        ->first();
                    $last_in = $attendances[$staff_ara_id][$date_string]['movements']
                        ->where('direction', 'in')
                        ->sortByDesc('id')
                        ->first();
                    $last_out = $attendances[$staff_ara_id][$date_string]['movements']
                        ->where('direction', 'out')
                        ->sortByDesc('id')
                        ->first();

                    $attendances[$staff_ara_id][$date_string]['schedule'] = $this->checkDaySchedule($schedule[$staff_ara_id], $date_string, $count_attendance[$staff_ara_id][$date_string], $first_in->hour);

                    $attendances[$staff_ara_id][$date_string]['hours on prem'] = $this->calcHoursInPrem($attendances[$staff_ara_id][$date_string]['movements']);

                    $lateOrAbsentStatus = $this->lateOrAbsentStatus($first_in->hour);
                    if(!$last_out){
                        $attendances[$staff_ara_id][$date_string]['day_attendance'] = [
                            'date' => $date_string,
                            'resumed' => $this->resolveTo12HourClock($first_in->hour) . ':' . $first_in->minutes . $first_in->meridien,
                            'closed' => '-',
                            'hours' => 0,
                            'weekday' => $date_day,
                            'day_schedule' => $this->checkDaySchedule($schedule[$staff_ara_id], $date_string, count($attendances[$staff_ara_id][$date_string]['movements']), $first_in->hour),
                            'status' => $lateOrAbsentStatus,
                            'closing_status' => $lateOrAbsentStatus == 'absent' ? ' ' : $this->leftEarlyStatus(null, $first_in->created_at, $last_in),
                        ];
                    } else {
                        $attendances[$staff_ara_id][$date_string]['day_attendance'] = [
                            'date' => $date_string,
                            'resumed' => $this->resolveTo12HourClock($first_in->hour) . ':' . $first_in->minutes . $first_in->meridien,
                            'closed' => $this->resolveTo12HourClock($last_out->hour) . ':' . $last_out->minutes. $last_out->meridien,
                            'hours' => $attendances[$staff_ara_id][$date_string]['hours on prem'],
                            'weekday' => $first_in->week_day,
                            'day_schedule' => $this->checkDaySchedule($schedule[$staff_ara_id], $date_string, count($attendances[$staff_ara_id][$date_string]['movements']), $first_in->hour),
                            'status' => $lateOrAbsentStatus,
                            'closing_status' => $lateOrAbsentStatus == 'absent' ? ' ' : $this->leftEarlyStatus($last_out, $first_in->created_at, $last_in),
                        ];
                    }
                }else{
                    $attendances[$staff_ara_id][$date_string]['day_attendance'] = [
                        'date' => $date_string,
                        'resumed' => ' ',
                        'closed' => ' ',
                        'hours' => 0,
                        'weekday' => $date_day,
                        'day_schedule' => $this->checkDaySchedule($schedule[$staff_ara_id], $date_string, count($attendances[$staff_ara_id][$date_string]['movements'])),
                            'status' => 'absent',
                        'closing_status' => ' ',
                    ];
                }

                if($attendances[$staff_ara_id][$date_string]['day_attendance']['status'] == 'late' || $attendances[$staff_ara_id][$date_string]['day_attendance']['status'] == 'absent' && !in_array($date['week_day'], ['Saturday', 'Sunday'])) {
                    $attendances[$staff_ara_id][$date_string]['day_attendance']['manager_auth'] = $this->findAuthorizationForDate($date_string, $authorizations[$staff_ara_id]);

                }

            }
            unset($staffAttendances);
        }


        // Pass the attendance data to the view and display the HTML table
        return view('frontend.staff_attendance.all_staff_attendance')->with([
            'staffMembers' => $staffMembers,
            'attendances' => $attendances,
            'from_date' => $from_date,
            'from_date_temp' => $from_date_temp,
            'to_date' => $to_date,
            'dates' => $dates,
            'auth_perm' => $auth_perm
        ]);
    }

    public function resolveTo12HourClock($hour)
    {
        return $hour > 12 ? ($hour - 12) : $hour;
    }

    public static function findAuthorizationForDate($dateToCheck, $authorizations)
    {
        if(is_null($authorizations))
            return null;

        // Find the first authorization where the date is between start_date and end_date (inclusive)
        $authorization = $authorizations->where('start_date', '<=', $dateToCheck)
            ->where('end_date', '>=', $dateToCheck)
            ->first();

        // If not found, check if the date is greater than or equal to start_date when is_indefinite is 1
        if (!$authorization) {
            $authorization = $authorizations->where('is_indefinite', 1)
                ->where('start_date', '<=', $dateToCheck)
                ->first();
        }

        return $authorization;
    }

    public function lateOrAbsentStatus($firstIn = null)
    {
        if(is_null($firstIn)){
            return 'absent';
        }

        if($firstIn >= 9){
            return 'late';
        }

        return 'early';
    }

    public function leftEarlyStatus($lastOut = null, $created_at = null, $last_in = null)
    {
        if(!is_null($lastOut) && !is_null($last_in) && $last_in->created_at > $lastOut->created_at){
            return 'wasn\'t clocked out';
        }

        if(is_null($lastOut)){
            if(is_null($created_at) || substr(now(), 0, 10) == substr($created_at, 0, 10)) {
                return ' ';
            }else{
                return 'wasn\'t clocked out';
            }
        }

        if($lastOut->hour < 17){
            return 'closed early';
        }

        return '';
    }

    public function calcHoursInPrem($attendances)
    {
       if(is_null($attendances))
           return 0;

        $inTime = null;
        $outTime = null;
        $totalHours = 0;

// Loop through the attendance records
        foreach ($attendances as $attendance) {
            if ($attendance->direction === 'in') {
                $inTime = Carbon::parse($attendance->created_at);
            } elseif ($attendance->direction === 'out') {
                $outTime = Carbon::parse($attendance->created_at);

                if($inTime) {
                    // Calculate the duration between the in and out times
                    $duration = $inTime->diffInMinutes($outTime) / 60.0;
                    $totalHours += $duration;
                }

                $inTime = null;
                $outTime = null;
            }
        }

        return number_format($totalHours);
    }

    public function checkDaySchedule($schedule_all, $date, $attendance_count = null, $first_in_hour = null)
    {
        $date = Carbon::parse($date);
        if(!is_null($schedule_all)) {
            $schedule = $schedule_all
                ->where('week_day', strtolower($date->format('l')))
                ->first();
        }else{
            $schedule = null;
        }

        $show = 'show';
        if(is_null($attendance_count) || $attendance_count == 0)
            $show = 'no show';

        $workdays = [
            'monday',
            'tuesday',
            'wednesday',
            'friday',
            'thursday',
        ];

        if(!in_array(strtolower($date->format('l')), $workdays)){
            $location = 'Remote';
            $show = 'weekend';
        }else if(!$schedule || !is_object($schedule) || $schedule->location == 'On duty'){
            $location = 'On duty';
        }else{
            $location = $schedule->location;
        }


        $colors = [
            'On duty - no show' => '#FFADAD',
            'On duty - show' => '#FFFFFF',
//          'Remote - no show' => '#4cb944',
            'Remote - no show' => '#F5F5F5',
            'Remote - show' => '#FDFFB6',
            'Remote - weekend' => '#CAFFBF',
//            'On duty - late' => '#dc2f02',
            'On duty - late' => '#F07166',
        ];

//        $location = is_object($schedule) ? $schedule->location : 'none';

        // if($staffAraId == '4534')
        // Log::info($staffAraId.': '.$location.' - '.$show.', $date: '.$date.', day: '.strtolower($date->format('l')).', $attendance_count: '.$attendance_count);

        if(!is_null($first_in_hour) && $first_in_hour >= 9){
            $color = $colors['On duty - late'];
        }
        $data = [
            'location' => $location,
            'colour' => isset($color) ? $color : ($colors[$location.' - '.$show] ?? '#ffb563'),
            'weekday' => strtolower($date->format('l')),
            'schedule' => $schedule
        ];

        return $data;
    }


}
