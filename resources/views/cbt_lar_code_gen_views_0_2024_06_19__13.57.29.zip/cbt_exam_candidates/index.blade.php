@extends('frontend.layouts.app')

@section('content')

    @if(Session::has('success_message'))
        <div class="alert alert-success alert-dismissible" role="alert">
            {!! session('success_message') !!}

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card text-bg-theme">

        <div class="card-header d-flex justify-content-between align-items-center p-3">
            <h4 class="m-0">Cbt Exam Candidates</h4>
            <div>
                <a href="{{ route('cbt_exam_candidates.cbt_exam_candidate.create') }}" class="btn btn-secondary" title="Create New Cbt Exam Candidate">
                    <span class="fa-solid fa-plus" aria-hidden="true"></span>
                </a>
            </div>
        </div>

        @if(count($cbtExamCandidates) == 0)
            <div class="card-body text-center">
                <h4>No Cbt Exam Candidates Available.</h4>
            </div>
        @else
        <div class="card-body p-0">
            <div class="table-responsive">

                <table class="table table-striped ">
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Staff Ara</th>
                            <th>Cbt Exam</th>
                            <th>Surname</th>
                            <th>First Name</th>
                            <th>Other Names</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>State</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($cbtExamCandidates as $cbtExamCandidate)
                        <tr>
                            <td class="align-middle">{{ $cbtExamCandidate->email }}</td>
                            <td class="align-middle">{{ optional($cbtExamCandidate->staffAra)->id }}</td>
                            <td class="align-middle">{{ optional($cbtExamCandidate->CbtExam)->title }}</td>
                            <td class="align-middle">{{ $cbtExamCandidate->surname }}</td>
                            <td class="align-middle">{{ $cbtExamCandidate->first_name }}</td>
                            <td class="align-middle">{{ $cbtExamCandidate->other_names }}</td>
                            <td class="align-middle">{{ $cbtExamCandidate->age }}</td>
                            <td class="align-middle">{{ $cbtExamCandidate->gender }}</td>
                            <td class="align-middle">{{ $cbtExamCandidate->state }}</td>

                            <td class="text-end">

                                <form method="POST" action="{!! route('cbt_exam_candidates.cbt_exam_candidate.destroy', $cbtExamCandidate->id) !!}" accept-charset="UTF-8">
                                <input name="_method" value="DELETE" type="hidden">
                                {{ csrf_field() }}

                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="{{ route('cbt_exam_candidates.cbt_exam_candidate.show', $cbtExamCandidate->id ) }}" class="btn btn-info" title="Show Cbt Exam Candidate">
                                            <span class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></span>
                                        </a>
                                        <a href="{{ route('cbt_exam_candidates.cbt_exam_candidate.edit', $cbtExamCandidate->id ) }}" class="btn btn-primary" title="Edit Cbt Exam Candidate">
                                            <span class="fa-regular fa-pen-to-square" aria-hidden="true"></span>
                                        </a>

                                        <button type="submit" class="btn btn-danger" title="Delete Cbt Exam Candidate" onclick="return confirm(&quot;Click Ok to delete Cbt Exam Candidate.&quot;)">
                                            <span class="fa-regular fa-trash-can" aria-hidden="true"></span>
                                        </button>
                                    </div>

                                </form>

                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

            </div>

            {!! $cbtExamCandidates->links('pagination') !!}
        </div>

        @endif

    </div>
@endsection
