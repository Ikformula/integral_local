@extends('frontend.layouts.app')

@section('title', 'Staff Travel Dashboard' )

@push('after-styles')
    @include('includes.partials._datatables-css')
@endpush


@section('content')

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header">
                            <h4>[[Data Visualizations]]</h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header">
                            <h4>Bookings</h4>
                        </div>
                        <div class="card-body table-responsive">
                            @include('frontend.staff_travel._bookings_table')
                        </div>
                        <div class="card-footer">
                           <a href="{{ route('frontend.staff_travel.bookings') }}" class="btn btn-primary"> View All Bookings </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('after-scripts')
    @include('includes.partials._datatables-js')
    <script>
        $(".table").DataTable({
            "responsive": false, "lengthChange": false, "autoWidth": true, paging: false, scrollY: 465,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('.table_wrapper .col-md-6:eq(0)');
    </script>
@endpush
