<?php

namespace App\Http\Controllers\Frontend\User\CBT;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CBTAdminController extends Controller
{
    //
}
