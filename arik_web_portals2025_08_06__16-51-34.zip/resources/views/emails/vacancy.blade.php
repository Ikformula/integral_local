{!! $data['email_body'] !!}
