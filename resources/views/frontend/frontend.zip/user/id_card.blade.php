@extends('frontend.layouts.app')

@section('title', 'Staff ID Card' )

@push('after-styles')
    <link rel="stylesheet" href="{{ asset('adminlte3.2/plugins/select2/css/select2.min.css') }}">
    <link rel="stylesheet"
          href="{{ asset('adminlte3.2/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">

    <style>
        .id_card_card {
            position: -webkit-sticky;
            position: sticky;
            top: 100px;
        }
    </style>
@endpush

@section('content')

    <section class="content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-sm-9">
                    <div class="callout callout-info mb-3">
                        <h5>{{ $department_members_uploaded_id_count }} out of {{ $department_members_count }}</h5>

                        <p>Number of staff members in {{ $staff->department_name }} who have updated their ID card on
                            this portal</p>
                    </div>

                    @include('frontend.includes._staff-info-summary')

                    @if($logged_in_user->can('manage own unit info') || $logged_in_user->can('update other staff info'))
                    <div class="card arik-card animate__animated animate__backInDown">
                        <div class="card-header">
                            <h3 class="card-title">
                                Staff Member Manager Setting
                            </h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('frontend.user.profile.updateManager') }}" method="POST">
                                @csrf
                                <input type="hidden" name="staff_ara_id" value="{{ $staff->staff_ara_id }}">

                                <div class="form-group">
                                    <label for="manager_ara_id">Manager</label>
                                    <select class="form-control" name="manager_ara_id" id="manager_ara_id">
                                        @if(!is_null($manager))
                                            <option selected value="{{ $staff->manager_ara_id }}">{{ $manager->name }}, {{ $staff->manager_ara_id }}</option>
                                        @else
                                            <option selected>Please Select One</option>
                                        @endif
                                        @foreach($department_members as $staff_member)
                                            <option value="{{ $staff_member->staff_ara_id }}">{{ $staff_member->name }}, {{ $staff_member->staff_ara_id }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary float-right">Update</button>
                            </form>
                        </div>
                    </div>
                    @endif



                    <div class="card arik-card animate__animated animate__backInDown">
{{--                        @if(is_null($staff->id_card_file_name) || $logged_in_user->can('manage own unit info') || $logged_in_user->can('update other staff info'))--}}
                            <div class="card-header">
                                <h3 class="card-title">
                                    ID Card Update (Kindly fill and submit the form below)
                                </h3>
                            </div>
                            <div class="card-body">
                                <form action="{{ route('frontend.user.profile.uploadIDcard') }}" method="POST"
                                      enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="staff_ara_id" value="{{ $staff->staff_ara_id }}">
                                    <div class="form-group">
                                        <label for="id_card_file">ID Card Photo</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" name="id_card_file"
                                                       id="id_card_file" {{ isset($staff->id_card_file_name) ? '' : 'required' }} accept="image/jpeg, image/JPEG, image/png, image/PNG, image/jpg, image/JPG" onchange="showImgPreview(event)">
                                                <label class="custom-file-label" for="id_card_file">Choose Scanned
                                                    image File</label>
                                            </div>
                                        </div>
                                        <span class="text-info">Please scan/capture without the ID card casing</span>
                                    </div>

                                    <div class="form-group">
                                        <label for="surname">Surname</label>
                                        <input type="text" class="form-control"
                                               value="{{ isset($staff->surname) ? $staff->surname : '' }}" id="surname"
                                               name="surname" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="other_names">Other Names</label>
                                        <input type="text" class="form-control"
                                               value="{{ isset($staff->other_names) ? $staff->other_names : '' }}"
                                               id="other_names" name="other_names" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="paypoint">Paypoint</label>
                                        <input type="text" class="form-control"
                                               value="{{ isset($staff->paypoint) ? $staff->paypoint : '' }}"
                                               id="paypoint" name="paypoint" maxlength="3" placeholder="LOS">
                                    </div>

                                    <div class="form-group">
                                        <label for="location">Location</label>
                                        <select class="form-control" name="location" id="location" required>
                                        @if(isset($staff->location))
                                            <option selected>{{ $staff->location }}</option>
                                            @else
                                                <option selected disabled>Please select an option</option>
                                        @endif
                                            <option>ABUJA FCT</option>
                                            <option>ABIA</option>
                                            <option>ADAMAWA</option>
                                            <option>AKWA IBOM</option>
                                            <option>ANAMBRA</option>
                                            <option>BAUCHI</option>
                                            <option>BAYELSA</option>
                                            <option>BENUE</option>
                                            <option>BORNO</option>
                                            <option>CROSS RIVER</option>
                                            <option>DELTA</option>
                                            <option>EBONYI</option>
                                            <option>EDO</option>
                                            <option>EKITI</option>
                                            <option>ENUGU</option>
                                            <option>GOMBE</option>
                                            <option>IMO</option>
                                            <option>JIGAWA</option>
                                            <option>KADUNA</option>
                                            <option>KANO</option>
                                            <option>KATSINA</option>
                                            <option>KEBBI</option>
                                            <option>KOGI</option>
                                            <option>KWARA</option>
                                            <option>LAGOS</option>
                                            <option>NASSARAWA</option>
                                            <option>NIGER</option>
                                            <option>OGUN</option>
                                            <option>ONDO</option>
                                            <option>OSUN</option>
                                            <option>OYO</option>
                                            <option>PLATEAU</option>
                                            <option>RIVERS</option>
                                            <option>SOKOTO</option>
                                            <option>TARABA</option>
                                            <option>YOBE</option>
                                            <option>ZAMFARA</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="department_name">Department</label>
                                        <select class="form-control" name="department_name" id="department_name" required>
                                        @if(isset($staff->department_name))
                                            <option selected>{{ $staff->department_name }}</option>
                                            @else
                                            <option selected disabled>Please select an option</option>
                                        @endif
                                            @include('includes.partials._departments-option-list')
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="location_in_hq">Current location at head office</label>
                                        <select class="form-control" name="location_in_hq" id="location_in_hq"
                                                required>
                                            @if(isset($staff->location_in_hq))
                                                <option selected>{{ $staff->location_in_hq }}</option>
                                            @else
                                                <option selected disabled>Please select an option</option>
                                            @endif
                                            <option>Old building</option>
                                            <option>New building</option>
                                            <option>Flight ops building</option>
                                            <option>Technical hangar</option>
                                            <option>Transport maintenance</option>
                                            <option>Catering</option>
                                            <option>Commercial store</option>
                                            <option>Main gate</option>
                                            <option>Domestic Airport</option>
                                            <option>International Airport</option>
                                            <option>Outstation</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="id_expiry_date">ID Card Expiry Date</label>
                                        <input type="date" name="id_expiry_date" class="form-control"
                                               id="id_expiry_date" min="{{ \Carbon\Carbon::today()->toDateString() }}"
                                               required
                                               value="{{ isset($staff->id_expiry_date) ? $staff->id_expiry_date : ''}}">
                                        <span class="text-muted">This will help for renewal of the ID card</span>
                                    </div>

                                    <div class="form-group">
                                        <label for="remarks">Remarks (If any; with regards to your ID Card)</label>
                                        <textarea class="form-control" name="remarks" id="remarks">{{ $staff->id_remarks ?? '' }}</textarea>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
{{--                        @endif--}}
                        <div class="card-footer">
                            <span>If you have any issues or complaints kindly send a message to dapasisi.tom-west@arikair.com or mariam.omoniyi@arikair.com</span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="card animate__animated animate__backInDown id_card_card">
                        <img class="card-img rounded"
                             src="{{ !is_null($staff->id_card_file_name) ? asset('img/id_cards/'.$staff->id_card_file_name) : asset('img/ID Card-cuate.svg') }}"
                             id="id-card-preview">
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('after-scripts')
    <script src="{{ asset('adminlte3.2/plugins/select2/js/select2.full.min.js') }}"></script>
    <script>
        $('.select2').select2({
            theme: 'bootstrap4'
        });
    </script>

    <script>
        function showImgPreview(event) {
    if (event.target.files.length > 0) {
        var file = event.target.files[0];
        var allowedTypes = ["image/jpeg", "image/png", "image/jpg"]; // Add any other image MIME types you want to allow

        if (allowedTypes.includes(file.type)) {
            var src = URL.createObjectURL(file);
            var preview = document.getElementById("id-card-preview");
            preview.src = src;
            // preview.style.display = "block";
        } else {
            alert("Please select a valid image file.");
            // Reset the file input if needed
            event.target.value = "";
        }
    }
}
    </script>
@endpush
