{{--Gross Sales--}}
@include('frontend.business_goals.parts.table2xlsx_button', ['table_id' => 'ba_'. $business_area_id] )
<table class="table table-hover table-sm" id="ba_{{ $business_area_id }}">
    <thead class="bg-secondary">
    <tr>
        <th colspan="4" class="bg-navy">{{ $business_area->name }} Report</th>
    </tr>
    <tr>
        <td>Gross Sales Revenue (NGN)</td>
        <td>Wk {{ $week_in_focus->week_number }} <small>({{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }})</small></td>
        <td>Previous Wk<small>({{ $presentation_data['titles']['last week'] }})</small></td>
        <td>Variance</td>
    </tr>
    </thead>
    <tbody>
    @php
        $current_week_total = $prev_week_total = 0;
    @endphp

    @foreach($form_fields as $field)
        @php
        $current_week = isset($presentation_data['current_week'][$field->id]) ? $presentation_data['current_week'][$field->id]['total'] : null;
        $prev_week = isset($presentation_data['previous_week'][$field->id]) ? $presentation_data['previous_week'][$field->id]['total'] : null;
        $variance = isset($current_week) && isset($prev_week) ? round((($current_week - $prev_week) / $current_week) * 100, 2).'%' : 'N/A';
        $current_week_total += ($field->form_type == 'number' && isset($current_week)) ? $current_week : 0;
        $prev_week_total += ($field->form_type == 'number' && isset($prev_week)) ? $prev_week : 0;
    @endphp
    <tr>
        <td>{{ $field->label }}</td>
        <td>{{ isset($current_week) ? '₦' : '' }}{{ number_format($current_week) ?? 'N/A'}}</td>
        <td>{{ isset($prev_week) ? '₦' : '' }}{{ number_format($prev_week) ?? 'N/A'}}</td>
        <td @if($variance < 0)  style="color: #DF356F" @endif>{{ $variance}}</td>
    </tr>
@endforeach
    <tr>
        <th>Total</th>
        <th>{{ number_format($current_week_total) }}</th>
        <th>{{ number_format($prev_week_total) }}</th>
        <th>{{ (($current_week_total - $prev_week_total) / $current_week_total) * 100 }}%</th>
    </tr>
    </tbody>
</table>
