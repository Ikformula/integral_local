<?php


namespace App\Http\Controllers\Traits;


use App\Models\EcsClient;
use App\Models\EcsClientAccountSummary;
use Carbon\Carbon;
use Illuminate\Http\Request;

trait EcsClientTransactionsTrait
{
    public function summariesList(Request $request, $other_params = [])
    {
        $client = null;
        if($request->has('client_id') && $request->client_id != 'All')
            $client = EcsClient::find($request->client_id);

        if(isset($other_params['client']))
            $client = $other_params['client'];

//        if(isset($client)){
//            $earliest_summary = EcsClientAccountSummary::where('client_id', $client->id)->orderBy('created_at', 'ASC')->first();
//        }else{
//            $earliest_summary = EcsClientAccountSummary::whereNotNull('id')->orderBy('created_at', 'ASC')->first();
//        }
//        if(!isset($earliest_summary))
            $earliest_summary = EcsClientAccountSummary::whereNotNull('id')->orderBy('created_at', 'ASC')->first();
        $earliest_date = $earliest_summary->created_at;

        if($request->filled('from_date')){
            $validated = $request->validate([
                'from_date' => ['before:tomorrow']
            ]);
            $from_date_temp = Carbon::createFromFormat('Y-m-d', $request->from_date)->startOfDay();
        } else {
            $from_date_temp = $earliest_date;
        }

        if($request->filled('to_date')){
            $validated = $request->validate([
                'to_date' => ['before:tomorrow', 'after_or_equal:from_date']
            ]);
            $to_date_temp = Carbon::createFromFormat('Y-m-d', $request->to_date)->endOfDay();
        } else {
            $to_date_temp = Carbon::today();
        }

        $from_date = $from_date_temp->copy();
        $to_date = $to_date_temp->copy();
        $query = EcsClientAccountSummary::query()
            ->whereBetween('created_at', [$from_date_temp, $to_date_temp]);

        if(isset($client))
            $query->where('client_id', $client->id);

        $filterSwitch = $request->input('filterSwitch', 'allStatusesSwitch');
        if($filterSwitch !== 'allStatusesSwitch') {
            if ($filterSwitch === 'disputeSwitch') {
                $query->whereNotNull('client_disputed_at');
            } elseif ($filterSwitch === 'approvedSwitch') {
                $query->whereNotNull('client_approved_at');
            } elseif ($filterSwitch === 'unattendedSwitch') {
                $query->whereNull('client_approved_at')->whereNull('client_disputed_at');
            }
        }

        $items = $query->orderBy('created_at', 'DESC')->get();

        return view('frontend.ecs_external.account_summaries')->with([
            'items' => $items,
            'from_date' => $from_date,
            'to_date' => $to_date,
            'params' => $request->query(),
            'earliest_date' => $earliest_date,
            'client' => $client
        ]);
    }

    public function addTransactionSummary(EcsClient $client, $amount, $details = '', $type = 'credit', $ticket_number = null)
    {
        $summary = new EcsClientAccountSummary();
        if($type == 'credit'){
            $summary->credit_amount = $amount;
            $working_amount = $amount;
        } else {
            $summary->debit_amount = $amount;
            $working_amount = -1 * $amount;
        }

        $summary->details = $details;
        $new_balance = $client->current_balance + $working_amount;
        $summary->balance = $new_balance;
        $summary->client_id = $client->id;
        $summary->ticket_number = $ticket_number;
        $summary->agent_user_id = auth()->id();
        $summary->save();
        $client->current_balance = $new_balance;
        $client->save();
    }

    public function addDisputeMessage(EcsClientAccountSummary $summary, $msg = '')
    {
        if($msg == '' || is_null($msg))
            return false;

        $sender = auth()->user();
        $current_messages = $summary->messages;
        if(!empty($current_messages) && checkIsJson($current_messages)) {
            $current_messages_arr = json_decode($current_messages);
        }else{
            $current_messages_arr = [];
        }

            $current_messages_arr[] = [
                'sender_id' => $sender->id,
                'sender_name' => $sender->full_name,
                'sent_at' => now(),
                'sent_at_human' => now()->toDayDateTimeString(),
                'message' => $msg,
                'summary_id' => $summary->id
            ];

        $summary->messages = json_encode($current_messages_arr);
        $summary->save();

        return true;
    }

    public function totalSalesStat($params = [])
    {
        // Code for getting total sales statistics
        $query = EcsClientAccountSummary::query();
        if(isset($params['client_id']) && !empty($params['client_id'])) {
            $query->where('client_id', $params['client_id']);
        }
        if(isset($params['from_date']) && !empty($params['from_date'])) {
            $query->whereDate('created_at', '>=', $params['from_date']);
        }
        if(isset($params['to_date']) && !empty($params['to_date'])) {
            $query->whereDate('created_at', '<=', $params['to_date']);
        }
        if (isset($params['agent_user_id']) && !empty($params['agent_user_id'])) {
            $query->where('agent_user_id', $params['agent_user_id']);
        }

        $totalCredit = $query->sum('credit_amount');
        $totalDebit = $query->sum('debit_amount');
//        $totalBalance = $query->sum('balance');

        return [
            'total_credit' => $totalCredit,
            'total_debit' => $totalDebit,
//            'total_balance' => $totalBalance,
            'params' => $params
        ];
    }

    public function numSummaries($params = [])
    {
        // Code for getting total sales statistics
        $query = EcsClientAccountSummary::query();
        if(isset($params['client_id']) && !empty($params['client_id'])) {
            $query->where('client_id', $params['client_id']);
        }
        if(isset($params['from_date']) && !empty($params['from_date'])) {
            $query->whereDate('created_at', '>=', $params['from_date']);
        }
        if(isset($params['to_date']) && !empty($params['to_date'])) {
            $query->whereDate('created_at', '<=', $params['to_date']);
        }
        if (isset($params['agent_user_id']) && !empty($params['agent_user_id'])) {
            $query->where('agent_user_id', $params['agent_user_id']);
        }

        $approvedQuery = clone $query;
        $unapprovedQuery = clone $query;

        $numApproved = $approvedQuery->whereNotNull('client_approved_at')->count();
        $numPending = $unapprovedQuery->whereNull('client_approved_at')->whereNull('client_disputed_at')->count();
        $numDisputed = $query->whereNotNull('client_disputed_at')->whereNull('client_approved_at')->count();

        return [
            'total_approved' => $numApproved,
            'total_pending' => $numPending,
            'total_disputed' => $numDisputed,
            'params' => $params
        ];
    }


}
