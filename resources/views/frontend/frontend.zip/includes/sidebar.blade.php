<!-- Main Sidebar Container -->
<aside class="main-sidebar elevation-4 bg-navy sidebar-dark-maroon">
    <!-- Brand Logo -->
    <a href="{{ route('frontend.index') }}" class="brand-link bg-navy">
        <img src="{{ asset(config('view.logo.gray')) }}" alt="Arik Air Logo" class="brand-image " style="opacity: .8">
        <span class="brand-text font-weight-light">{{ app_name() }}</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="{{ $logged_in_user->picture }}" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="{{ route('frontend.user.profile.editIDcard') }}?staff_ara_id={{ $logged_in_user->staff_member->staff_ara_id ?? '0000' }}" class="d-block text-white">{{ $logged_in_user->full_name }}</a>
            </div>
        </div>

        <!-- SidebarSearch Form -->
        @if(1 < 0)
        <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                        <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
            </div>
        </div>
        @endif

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                @foreach($menus as $menu)
                    @if(isset($menu['links']))
                    <li class="nav-item">
                        <a href="{{ $menu['link'] }}" class="nav-link sidebar-link">
                            <i class="nav-icon {{ $menu['icon'] }}"></i>
                            <p>
                                {{ $menu['title'] }}
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                    @foreach($menu['links'] as $link)
                            <li class="nav-item">
                                <a href="{{ $link['link'] }}" class="nav-link sidebar-link">
                                    <i class="{{ $link['icon'] }} nav-icon"></i>
                                    <p>{{ $link['title'] }}</p>
                                </a>
                            </li>
                    @endforeach
                        </ul>
                    </li>
                    @else
                        <li class="nav-item">
                            <a href="{{ $menu['link'] }}" class="nav-link sidebar-link">
                                <i class="nav-icon {{ $menu['icon'] }}"></i>
                                <p>
                                    {{ $menu['title'] }}
                                </p>
                            </a>
                        </li>
                    @endif

                @endforeach

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
