<?php
namespace App\Models;

use App\Models\Auth\User;
use Illuminate\Database\Eloquent\Model;

class EcsBooking extends Model
{
    protected $fillable = [
        'booking_reference',
        'penalties',
        'ticket_fare',
        'remarks',
        'for_date',
        'agent_user_id',
        'client_id'
    ];

    public function agent_user_idRelation()
    {
        return $this->belongsTo(Auth\User::class, 'agent_user_id');
    }

    public function client_idRelation()
    {
        return $this->belongsTo(EcsClient::class, 'client_id');
    }

    public function flights()
    {
        return $this->hasMany(EcsFlight::class, 'ecs_booking_id');
    }

    public function flight_transactions()
    {
        return $this->hasMany(EcsFlightTransaction::class, 'ecs_booking_id');
    }
}
