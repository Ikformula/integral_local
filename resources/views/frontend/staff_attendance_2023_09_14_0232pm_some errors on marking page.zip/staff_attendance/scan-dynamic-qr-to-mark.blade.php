@extends('frontend.staff_attendance.mark-attendance-layout')

@section('content')
    <div class="row justify-content-center">
        <div class="col-6">
            <img src="http://arikportals.arikair.com/qr_code/qr_image_from_GET?str_to_convert=http://arikportals.arikair.com/integral/public/attendance?tsp={{ time() }}" class="img-fluid rounded">
        </div>
    </div>
@endsection
