<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EcsClient extends Model
{
    protected $fillable = ['name', 'current_balance', 'service_charge_amount', 'deal_code'];

    public function clientUsers()
    {
        return $this->hasMany(EcsClientUser::class, 'client_id');
    }
}
