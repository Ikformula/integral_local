{{-- Operational Delivery / Customer Service --}}
@include('frontend.business_goals.parts.table2xlsx_button', ['table_id' => 'ba_'. $business_area_id] )
<table class="table table-hover table-sm" id="ba_{{ $business_area_id }}">
    <thead class="bg-secondary">
    <tr>
        <th colspan="5" class="bg-navy">{{ $business_area->name }} Report</th>
    </tr>
    <tr>
        <td></td>
        <td>Target</td>
        <td>Actual: Wk {{ $week_in_focus->week_number }} <small>({{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }})</small></td>
        <td>Previous Wk ({{ $week_in_focus->week_number - 1 }})<small>({{ $presentation_data['titles']['last week'] }})</small></td>
        <td>Previous Mth <small>({{ $presentation_data['titles']['last month'] }})</small></td>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>On Time Punctuality</td>
        <td>{{ $presentation_data['current_week']['1']['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['current_week']['2']['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_week']['2']['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_month']['2']['total'] ?? 'N/A'}}%</td>
    </tr>
    <tr>
        <td>Load Factor</td>
        @php $load_factor_target = findFirstArrayWithValue($form_fields, 'Load Factor - Target');
        $load_factor_actual = findFirstArrayWithValue($form_fields, 'Load Factor - Actual');
        @endphp

        <td>{{ $presentation_data['current_week'][$load_factor_target['id']]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['current_week'][$load_factor_actual['id']]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_week'][$load_factor_actual['id']]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_month'][$load_factor_actual['id']]['total'] ?? 'N/A'}}%</td>
    </tr>
    <tr>
        @php $completion_factor_target = findFirstArrayWithValue($form_fields, 'Completion Factor - Target');
        $completion_factor_actual = findFirstArrayWithValue($form_fields, 'Completion Factor - Actual');
        @endphp
        <td>Completion Factor</td>
        <td>{{ $presentation_data['current_week'][$completion_factor_target['id']]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['current_week'][$completion_factor_actual['id']]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_week'][$completion_factor_actual['id']]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_month'][$completion_factor_actual['id']]['total'] ?? 'N/A'}}%</td>
    </tr>

        @php
            $mishandled = findFirstArrayWithValue($form_fields, 'Mishandled Baggages')['id'];
        $damaged = findFirstArrayWithValue($form_fields, 'Damaged Bags')['id'];
        // $pilfered = findFirstArrayWithValue($form_fields, 'Pilfered Bags')['id'];
        // $handled = findFirstArrayWithValue($form_fields, 'Handled Bags')['id'];
        @endphp
    <tr>
        <td>Mishandled Baggage</td>
        <td></td>
        <td>{{ $presentation_data['current_week'][$mishandled]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$mishandled]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_month'][$mishandled]['total'] ?? 'N/A'}}</td>
    </tr>
    <tr>
        <td>Damaged Bags</td>
        <td></td>
        <td>{{ $presentation_data['current_week'][$damaged]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_week'][$damaged]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['previous_month'][$damaged]['total'] ?? 'N/A'}}</td>
    </tr>
{{--    <tr>--}}
{{--        <td>Pilfered Bags</td>--}}
{{--        <td></td>--}}
{{--        <td>{{ $presentation_data['current_week'][$pilfered]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_week'][$pilfered]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_month'][$pilfered]['total'] ?? 'N/A'}}</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <td>Handled Bags</td>--}}
{{--        <td></td>--}}
{{--        <td>{{ $presentation_data['current_week'][$handled]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_week'][$handled]['total'] ?? 'N/A'}}</td>--}}
{{--        <td>{{ $presentation_data['previous_month'][$handled]['total'] ?? 'N/A'}}</td>--}}
{{--    </tr>--}}


    <tr>
        @php $complaints_target = findFirstArrayWithValue($form_fields, 'Customer Complaints/Requests Target')['id'];
        $Complaints = findFirstArrayWithValue($form_fields, 'Complaints')['id'];
        $Number_of_Complains = findFirstArrayWithValue($form_fields, 'Number of Complains')['id'];
        // $Requests = findFirstArrayWithValue($form_fields, 'Requests')['id'];
        @endphp

        <td>Customer Complaints/Requests</td>
        <td>{{ $presentation_data['current_week'][$complaints_target]['total'] ?? 'N/A'}}</td>
        <td>{{ $presentation_data['current_week'][$Complaints]['total'] ?? 'N/A'}} complaints,
            {{ $presentation_data['current_week'][$Number_of_Complains]['total'] ?? 'N/A'}} Customer Complains,
{{--            {{ $presentation_data['current_week'][$Requests]['total'] ?? 'N/A'}} requests</td>--}}
        <td>{{ $presentation_data['previous_week'][$Complaints]['total'] ?? ''}} complaints,
            {{ $presentation_data['previous_week'][$Number_of_Complains]['total'] ?? 'N/A'}} Customer Complains,
{{--            {{ $presentation_data['previous_week'][$Requests]['total'] ?? 'N/A'}} requests</td>--}}
        <td></td>
    </tr>
    <tr><td><small>(Complaints/1000 pax)</small></td></tr>
    <tr>
        @php $tech_desp_target = findFirstArrayWithValue($form_fields, 'Technical Despatch Rate Targeted')['id'];
        $tech_desp_actual = findFirstArrayWithValue($form_fields, 'Technical Despatch Rate Actual')['id'];
       @endphp
        <td>Technical Dispatch Rate</td>
        <td>{{ $presentation_data['current_week'][$tech_desp_target]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['current_week'][$tech_desp_actual]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_week'][$tech_desp_actual]['total'] ?? 'N/A'}}%</td>
        <td>{{ $presentation_data['previous_month'][$tech_desp_actual]['total'] ?? 'N/A'}}%</td>
    </tr>
    </tbody>
</table>
