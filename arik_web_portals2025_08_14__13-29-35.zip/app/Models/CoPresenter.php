<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoPresenter extends Model
{
    protected $fillable = ['staff_ara_id', 'business_area_id'];
}
