<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\ExternalVendor;
use App\Models\IcuActivity;
use App\Models\StaffMember;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\CurrencyTrait;

class IcuActivityAjaxController extends Controller
{
    use CurrencyTrait;

    public function index()
    {
        $icu_activities = IcuActivity::with([
            'vendor_idRelation',
            'beneficiary_staff_ara_idRelation',
            'entered_by_user_idRelation',
        ])->get();

        $external_vendors = ExternalVendor::all();
        $staff_members = StaffMember::all();
//        $currencies = ['NGN', 'USD', 'EUR', 'GBP'];

        return view('frontend.icu_activities.index', compact('icu_activities', 'external_vendors', 'staff_members'));
    }

    public function store(Request $request)
    {
        $arr = $request->all();
        $currencies = $this->currencies;

        foreach ($currencies as $code => $currency){
            if($request->has($currency['0'].'_amount')){
                $arr['trx_currency'] = $code;
                break;
            }
        }

        if($request->has('vendor_name')){
            $vendor = ExternalVendor::firstOrCreate(
                ['name' => $request->vendor_name]
            );

            $arr['vendor_id'] = $vendor->id;
        }

        IcuActivity::create($arr);
        return back()->withFlashSuccess('Internal Control Activity Report created successfully.');
    }

    public function update(Request $request, $id)
    {
        $arr = $request->all();
        if($request->has('vendor_name')){
            $vendor = ExternalVendor::firstOrCreate([
                ['name' => $request->vendor_name]
            ]);

            $arr['vendor_id'] = $vendor->id;
        }

        $icu_activities = IcuActivity::findOrFail($id);
        $icu_activities->update($request->all());
        return back()->withFlashSuccess('Internal Control Activity Report updated successfully.');
    }

    public function destroy($id)
    {
        IcuActivity::destroy($id);
        return back()->withFlashSuccess('Internal Control Activity Report deleted successfully.');
    }
}
