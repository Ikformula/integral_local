<form action="" method="GET">
    @csrf
    <input type="hidden" name="staff_ara_id" value="{{ $staff_ara_id ?? '' }}">
    <span>Showing attendance</span>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="from_date">From</label>
                <input type="date" name="from_date" id="from_date" value="{{ $from_date->toDateString() ?? '' }}" class="form-control">
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label for="to_date">To</label>
                <input type="date" name="to_date" id="to_date" value="{{ $to_date->toDateString() ?? '' }}" class="form-control">
            </div>
        </div>


    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="staff_ara_id">Staff ARA ID</label>
                <input type="text" name="staff_ara_id" id="staff_ara_id" value="{{ $_GET['staff_ara_id'] ?? '' }}" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="department">Department</label>
                <input type="text" name="department" id="department" value="{{ $_GET['department'] ?? ''  }}" class="form-control" list="departments-list">
                <datalist id="departments-list">
                    <option>SECURITY</option>
                    <option>CORPORATE SERVICES</option>
                    <option>COMMERCIAL</option>
                    <option>FINANCE</option>
                    <option>CEO OFFICE</option>
                    <option>FINANCE</option>
                    <option>OCC</option>
                    <option>TECHNICAL</option>
                    <option>FLIGHT OPERATIONS</option>
                    <option>CABIN OPERATIONS</option>
                    <option>CEO OFFICE - SAFETY</option>
                    <option>IT</option>
                    <option>QUALITY ASSURANCE</option>
                    <option>COMMERCIAL - SALES & DISTRIBUTION</option>
                    <option>FINANCE- REVENUE ACCOUNTING</option>
                    <option>COMMERCIAL - REVENUE MGT & PRICING</option>
                    <option>COMMERCIAL -MARKETING</option>
                    <option>ADMINISTRATION</option>
                    <option>HUMAN RESOURCES</option>
                    <option>INTERNAL CONTROL</option>
                    <option>GROUND OPERATIONS</option>
                </datalist>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="form-group">
                <label for="staff_name">Staff Name</label>
                <input type="text" name="staff_name" id="staff_name" value="{{ $_GET['staff_name'] ?? ''  }}" class="form-control">
            </div>
        </div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

</form>
