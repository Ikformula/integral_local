{{--Network Planning and Schedule--}}

@include('frontend.business_goals.dailies._table')
