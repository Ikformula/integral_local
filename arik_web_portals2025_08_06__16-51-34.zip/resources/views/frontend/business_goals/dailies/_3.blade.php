{{-- Operational Delivery / Customer Service --}}
    @php
    $custom_order = [2, 4, 5, 6, 12, 15, 28];
    @endphp

@include('frontend.business_goals.dailies._table')
