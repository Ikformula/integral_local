<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Attendance Marking | {{ app_name() }}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', app_name())</title>
    <meta name="description" content="@yield('meta_description', 'Arik Air Web Portals')">
    <meta name="author" content="@yield('meta_author', 'Asuquo Bartholomew Ikechukwu')">

    <!-- Favicons -->
    <link href="https://www.arikair.com/assets/images/favicon.ico" rel="icon">
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css"
        integrity="sha512-SbiR/eusphKoMVVXysTKG/7VseWii+Y3FdHrt0EpKgpToZeemhqHeZeLWLhJutz/2ut2Vw1uQEj2MbRF+TVBUA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('css/attendance-bootstrap.min.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <style>
        /*input::-webkit-outer-spin-button,*/
        /*input::-webkit-inner-spin-button {*/
        /*    display: none;*/
        /*}*/

        .bg-out-attendance {
            background-color: #C5C7DC;
        }

        .container {
            max-width: 95%;
            zoom: 90%;
        }
    </style>
</head>

<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-dark bg-primary fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#"><img src="{{ asset(config('view.logo.gray')) }}" alt="Arik Air Logo"
                    class="brand-image " style="opacity: .8"></a>
            <div class="row justify-content-end">
                <div class="col">
                    <div class="btn-group btn-group btn-block" role="group" aria-label="Large button group">
                        <button type="button" class="btn btn-outline-light">In
                            <span class="card-title" style="font-size:1.8em;" id="in_counter">{{ $stats['ins'] }}</span>
                        </button>
                        <button type="button" class="btn btn-outline-light">Out
                            <span class="card-title" style="font-size:1.8em;"
                                id="out_counter">{{ $stats['outs'] }}</span>
                        </button>
                        <button type="button" class="btn btn-outline-light ">In Premises
                            <span class="card-title" style="font-size:1.8em;"
                                id="on_prem_counter">{{ $stats['on_prem'] }}</span>
                        </button>
                    </div>
                </div>
            </div>
            {{--        <button class="navbar-toggler" type="button" > --}}
            {{--            <span class="navbar-toggler-icon text-white">Vehicles</span> --}}
            {{--        </button> --}}
            {{--        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" --}}
            {{--                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> --}}
            {{--            <span class="navbar-toggler-icon"></span> --}}
            {{--        </button> --}}

            {{--        <div class="collapse navbar-collapse" id="navbarResponsive"> --}}
            {{--            <ul class="navbar-nav ms-md-auto"> --}}
            {{--                <li class="nav-item"> --}}
            {{--                    <a href="javascript: void(0);" data-bs-toggle="modal" data-bs-target="#exampleModal" --}}
            {{--                       class="nav-link">Vehicles</a> --}}
            {{--                </li> --}}
            {{--            </ul> --}}
            {{--        </div> --}}
        </div>
    </nav>
    <!-- Page content-->
    <div style="margin-top: 6rem;"></div>
    <div class="container mt-5">
        <h4>ARIKPASS</h4>
        <div class="row">
            <div class="col-md-7">
                <div class="card mb-3 animate__animated animate__backInUp">
                    <div class="card-header">Staff Movement Timestamp - <strong><span id="MyClockDisplay"
                                onload="showTime()"></span></strong>
                    </div>
                    <div class="card-body">
                        @yield('content')
                    </div>
                </div>
            </div>


        </div>


    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"
        integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    

    <script>
        function showTime() {
            var date = new Date();
            var h = date.getHours(); // 0 - 23
            var m = date.getMinutes(); // 0 - 59
            var s = date.getSeconds(); // 0 - 59
            var session = "AM";

            // if (h == 0) {
            //     h = 12;
            // }

            // if (h > 12) {
            //     h = h - 12;
            //     session = "PM";
            // }

            h = (h < 10) ? "0" + h : h;
            m = (m < 10) ? "0" + m : m;
            s = (s < 10) ? "0" + s : s;

            var time = h + ":" + m + ":" + s;
            // var time = h + ":" + m + ":" + s + " " + session;
            document.getElementById("MyClockDisplay").innerText = time;
            document.getElementById("MyClockDisplay").textContent = time;

            setTimeout(showTime, 1000);

        }

        showTime();
    </script>
	
    @stack('after-scripts')

@if(1 < 0)
    <script>
        function searchVehicle(event) {
            event.preventDefault();
            var formData = new FormData(document.getElementById('attendance_form'));
            fetch('{{ route('search.vehicle') }}', {
                    method: 'POST',
                    body: formData
                })
                .then(
                    response => response.json())
                .then(function(data) {
                    if (data.found == true) {
                        $('#vehicle_search_result').html(`
                    <div class="card border-primary mb-3">
  <div class="card-header">Result</div>
  <div class="card-body">
    <h4 class="card-title">${data.vehicle.reg_number}</h4>
    <ul class="list-group">
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Staff Name: </strong> ${data.staff.surname} ${data.staff.other_names}
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Staff Department:</strong> ${data.staff.department_name}
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Staff ARA ID:</strong> ${data.staff.staff_ara_id}
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Parking zone:</strong> ${data.vehicle.parking_zone}
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Model:</strong> ${data.vehicle.model}
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Maker:</strong> ${data.vehicle.maker}
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Colour:</strong> <span class="badge" style="background-color: ${data.vehicle.colour}"> ${data.vehicle.colour}</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <strong>Type:</strong> ${data.vehicle.type}
  </li>
</ul>
  </div>
</div>
                    `);
                    } else {
                        $('#vehicle_search_result').html(`
                    <div class="pb-0 alert alert-dismissible alert-info">
                        No vehicle with that registration number found
                    </div>
                    `);
                    }
                }).catch(err => console.error(err));
        }


        document.getElementById("vehicle-search-form").addEventListener("submit", searchVehicle);
    </script>
    @endif

    @include('includes.partials.messages-toastr')
</body>

</html>
