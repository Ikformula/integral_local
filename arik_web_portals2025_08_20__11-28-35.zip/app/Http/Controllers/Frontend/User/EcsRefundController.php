<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\EcsRefund;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\EcsClientTransactionsTrait;

class EcsRefundController extends Controller
{
    use EcsClientTransactionsTrait;

    public function index()
    {
        $items = EcsRefund::all();
        return view('frontend.ecs_refunds.index', compact('items'));
    }

    public function create()
    {
        return view('frontend.ecs_refunds.create');
    }

    public function store(Request $request)
    {
        try {
            $refund = EcsRefund::create($request->all());

            $this->addTransactionSummary($refund->client_idRelation, $refund->amount_refundable, 'REFUND: '.$refund->surname.' '.$refund->first_name, 'credit', $refund->ticket_number);

            return redirect()->route('frontend.ecs_refunds.index')
                ->withFlashSuccess('EcsRefund created successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withErrors('Error creating EcsRefund: ' . $e->getMessage());
        }
    }

    public function show(EcsRefund $item)
    {
        return view('frontend.ecs_refunds.show', compact('item'));
    }

    public function edit(EcsRefund $item)
    {
        return view('frontend.ecs_refunds.edit', compact('item'));
    }

    public function update(Request $request, EcsRefund $item)
    {
        try {
            $item->update($request->all());
            return redirect()->route('frontend.ecs_refunds.index')
                ->withFlashSuccess('EcsRefund updated successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withErrors('Error updating EcsRefund: ' . $e->getMessage());
        }
    }

    public function destroy(EcsRefund $item)
    {
        try {
            $item->delete();
            return redirect()->route('frontend.ecs_refunds.index')
                ->withFlashSuccess('EcsRefund deleted successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withErrors('Error deleting EcsRefund: ' . $e->getMessage());
        }
    }
}
