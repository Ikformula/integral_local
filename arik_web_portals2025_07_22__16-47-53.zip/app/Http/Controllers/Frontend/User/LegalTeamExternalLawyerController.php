<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\LegalTeamExternalLawyer;
use Illuminate\Http\Request;

class LegalTeamExternalLawyerController extends Controller
{
    public function index()
    {
        $items = LegalTeamExternalLawyer::all();
        return view('frontend.legal_team_external_lawyers.index', compact('items'));
    }

    public function create()
    {
        return view('frontend.legal_team_external_lawyers.create');
    }

    public function store(Request $request)
    {
        try {
            LegalTeamExternalLawyer::create($request->all());
            return redirect()->route('frontend.legal_team_external_lawyers.index')
                ->withFlashSuccess('LegalTeamExternalLawyer created successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withErrors('Error creating LegalTeamExternalLawyer: ' . $e->getMessage());
        }
    }

    public function show(LegalTeamExternalLawyer $item)
    {
        return view('frontend.legal_team_external_lawyers.show', compact('item'));
    }

    public function edit(LegalTeamExternalLawyer $item)
    {
        return view('frontend.legal_team_external_lawyers.edit', compact('item'));
    }

    public function update(Request $request, LegalTeamExternalLawyer $item)
    {
        try {
            $item->update($request->all());
            return redirect()->route('frontend.legal_team_external_lawyers.index')
                ->withFlashSuccess('LegalTeamExternalLawyer updated successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withErrors('Error updating LegalTeamExternalLawyer: ' . $e->getMessage());
        }
    }

    public function destroy(LegalTeamExternalLawyer $item)
    {
        try {
            $item->delete();
            return redirect()->route('frontend.legal_team_external_lawyers.index')
                ->withFlashSuccess('LegalTeamExternalLawyer deleted successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->withErrors('Error deleting LegalTeamExternalLawyer: ' . $e->getMessage());
        }
    }
}
