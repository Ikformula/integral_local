<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\EcsFlightTransaction;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\EcsClientTransactionsTrait;

class EcsFlightTransactionAjaxController extends Controller
{
    use EcsClientTransactionsTrait;
    public function index()
    {
        $ecs_flight_transactions = EcsFlightTransaction::with([
            'ecs_booking_idRelation',
            'client_idRelation',
            'client_approver_idRelation',
        ])->get();

        return view('frontend.ecs_flight_transactions.index', compact('ecs_flight_transactions'));
    }

    public function store(Request $request)
    {
        $trx = EcsFlightTransaction::create($request->all());
        $booking = $trx->ecsBooking;
        if($trx->is_cancelled == 'no')
        $this->addTransactionSummary($booking->client_idRelation, $booking->ticket_fare + $booking->penalties + $trx->service_fee, 'TICKET SALES: '.$trx->surname.' '.$trx->first_name, 'debit', $trx->ticket_number);

        return back()->withFlashSuccess('Flight Transaction created successfully.');
    }

    public function update(Request $request, $id)
    {
        $ecs_flight_transactions = EcsFlightTransaction::findOrFail($id);
        if(is_null($ecs_flight_transactions->client_approved_at)) {
            $ecs_flight_transactions->update($request->all());
            // add/subtract the difference from the following trxs
            return back()->withFlashSuccess('Flight Transaction updated successfully.');
        }
        return back()->withFlashWarning('Transaction updates not allowed after client approval');
    }

    public function destroy($id)
    {
        EcsFlightTransaction::destroy($id);
        // add/subtract that amount from the following transactions
        return back()->withFlashSuccess('Flight Transaction deleted successfully.');
    }
}
