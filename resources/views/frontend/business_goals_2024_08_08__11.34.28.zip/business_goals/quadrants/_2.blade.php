{{--Ground Operations Weekly Report--}}
@include('frontend.business_goals.parts.table2xlsx_button', ['table_id' => 'ba_'. $business_area_id] )
<table class="table table-hover table-sm" id="ba_{{ $business_area_id }}">
    <thead>
    <tr>
        <th colspan="5" class="bg-navy">{{ $business_area->name }}  Report</th>
    </tr>
    <tr  style="background-color: #B3CEEB">
        <th></th>
        <th>Wk {{ $week_in_focus->week_number }} <small>({{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }})</small></th>
        <th>Previous Wk ({{ $week_in_focus->week_number - 1 }})<small>({{ $presentation_data['titles']['last week'] }})</small></th>
        <th>Difference</th>
        <th>COMMENTS</th>
    </tr>
    </thead>
    <tbody>
    @php
        // dd($form_fields_collection->where('id', 79));
             $current_week_total = $prev_week_total = 0;
             $custom_order = [73, 77, 79, 81, 83, 85, 89, 186, 91, 93, 95, 97, 99, 101, 103, 105, 107, 109, 188];
    @endphp

    {{--    @foreach($form_fields_collection->where('form_type', 'number') as $field)--}}
    @foreach($custom_order as $field_id)
        @php
            $field = $form_fields_collection->where('id', $field_id)->first();
               $current_week = isset($presentation_data['current_week'][$field->id]) ? $presentation_data['current_week'][$field->id]['total'] : null;
                $prev_week = isset($presentation_data['previous_week'][$field->id]) ? $presentation_data['previous_week'][$field->id]['total'] : null;
                $variance = isset($current_week) && isset($prev_week) ? ($current_week - $prev_week) : 'NIL';
                $variance = $variance != 0 ? $variance : 'NIL';
                // $current_week_total += ($field->form_type == 'number' && isset($current_week)) ? $current_week : 0;
                // $prev_week_total += ($field->form_type == 'number' && isset($prev_week)) ? $prev_week : 0;
                $variance_direction = is_numeric($variance) ? ($variance < 0 ? 'decrease' : 'increase') : '';
                if(findFirstArrayWithValue($form_fields, $field->label.' (Comment)')){
                    $comment[$field->id] = findFirstArrayWithValue($form_fields, $field->label.' (Comment)')['id'];
                }else{
                    $comment[$field->id] = '';
                }
        @endphp
        <tr>
            <td>{{ $field->label }}</td>
            <td>{{ isset($field->unit, $current_week) && $field->unit == '₦' ? '₦' : ''}}{{ number_format($current_week) ?? 'N/A'}}{{ isset($field->unit, $current_week) && $field->unit != '₦' ? $field->unit : ''}}</td>
            <td>{{ isset($field->unit, $prev_week) && $field->unit == '₦' ? '₦' : ''}}{{ number_format($prev_week) ?? 'N/A'}}{{ isset($field->unit, $prev_week) && $field->unit != '₦' ? $field->unit : ''}}</td>
            <td>{{ (isset($field->unit) && $field->unit == '₦' && is_numeric($variance)) ? '₦' : '' }}{{ is_numeric($variance) ? number_format(abs($variance)) : 'NIL'}}{{ (isset($field->unit) && $field->unit != '₦' && is_numeric($variance)) ? $field->unit : '' }} {{ $variance_direction }}</td>
            <td>{{ $presentation_data['current_week'][$comment[$field->id]]['total'] ?? 'N/A'}}</td>
        </tr>
    @endforeach
    </tbody>
</table>
