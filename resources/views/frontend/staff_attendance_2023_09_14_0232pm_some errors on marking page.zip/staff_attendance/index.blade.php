@extends('frontend.staff_attendance.mark-attendance-layout')

@section('content')
    <div class="row">
    <div class="col">
        <h4 class="card-title">Arik Air Staff Details</h4>
        <div class="row">
            <div class="col mb-4">
                <ul class="list-group" id="attendance_list_group">
                </ul>
            </div>
        </div>
    <form id="check_staff_info">
        {{-- @csrf --}}
        <input type="hidden" name="operator_user_id" value="{{ auth()->id() }}">
        <div class="my-2">
            <label for="staff_ara_id">ARA Number</label><br>
            <small class="text-info">You can now check for contract staff with letters in their ARA IDs e.g 8021c</small>
            <div class="input-group">
                <button class="btn btn-outline-danger" type="reset" id="clear-button">x</button>
                <input type="text" name="staff_ara_id" id="staff_ara_id" minlength="4" class="form-control" autofocus placeholder="1066">
                <button class="btn btn-outline-secondary" type="button" id="button-addon2">Check</button>
            </div>
            <small class="text-muted">Enter ARA number only</small>
        </div>
    </form>

    <form id="attendance_form">
        @csrf
        <input type="hidden" id="ara_id" name="staff_ara_id">

        <div class="form-group" id="temperature" style="display: none;">
            <label>Temperature</label>
            <input type="number" name="temperature" id="temperature_field" class="form-control">
        </div>

        <div class="form-group">
            <button type="button" id="attendance_button_in" class="btn btn-primary mark_attendance_buttons disabled">
                Mark In
            </button>

            <button type="button" id="attendance_button_out" class="btn btn-danger mark_attendance_buttons disabled float-right">
                Mark Out
            </button>
        </div>
    </form>
    </div>

    <div class="col mb-3" style="display: none" id="id_card_row">
        <div id="staff_details"></div>
        <img src="..." class="img-fluid rounded mx-auto d-block" alt="..." id="id_card">
    </div>
    </div>
@endsection

@push('after-scripts')
    <script>
        let in_count = {{ $stats['ins'] }};
        let out_count = {{ $stats['outs'] }};
        let on_prem_count = {{ $stats['on_prem'] }};

        function checkStaffInfo(event) {
            event.preventDefault();
            $('#id_card_row').hide();
            $('#temperature').hide();
            $('#staff_details').empty();
            $('#attendance_list_group').empty();
            {{-- $('#attendance_button').attr("class", "btn btn-block btn-danger disabled"); --}}
            $('.mark_attendance_buttons').attr("disabled", "disabled");

            var formData = new FormData(document.getElementById('check_staff_info'));
            fetch('{{ route('check_staff_info') }}', {
                    method: 'POST',
                    body: formData
                })
                .then(
                    response => response.json())
                .then(function(data) {
                    console.log(data);
                    if (typeof data.staff_member !== 'undefined') {
                        let surname = data.staff_member.surname == null ? '' : data.staff_member.surname;
                        if (data.staff_member.restrict_access_from != null) {
                            $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-danger">
                        <strong>Alert</strong>
<p>${surname} ${data.staff_member.other_names} <br>
Resigned at: ${data.staff_member.resigned_on} <br>
Restrict Access From ${data.staff_member.restrict_access_from}
</p>
                    </div>
                        `);
                        } else {
                            $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-success pr-1">
                        <strong>Staff Information</strong>
<p><strong>Name: </strong> ${surname} ${data.staff_member.other_names} <br>
<strong>Department: </strong> ${data.staff_member.department_name}<br>
<strong>Designation: </strong> ${data.staff_member.job_title}<br>
<strong>Paypoint: </strong> ${data.staff_member.paypoint}<br>
</p>
                    </div>
                        `);

                            $('#ara_id').val(data.staff_member.staff_ara_id);

                            // show ID card
                            $('#id_card').attr('src', '{{ asset('/img/id_cards') }}/' + data.staff_member
                                .id_card_file_name);
                            $('#id_card_row').show();
                            $('#temperature').show();


                            {{-- $('#attendance_button').attr("class", "btn btn-block btn-danger"); --}}
                            $('.mark_attendance_buttons').attr("disabled", false);
                        }


                    } else if (typeof data.msg !== 'undefined') {
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-warning">
                        <strong>Notice</strong>
<p>${data.msg}</p>
                    </div>
                        `);
                    } else if (typeof data.staff_member !== 'undefined' && data.staff_member.restrict_access_from !=
                        'undefined') {
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-danger">
                        <strong>Alert</strong>
<p>${surname} ${data.staff_member.other_names} <br>
Resigned at: ${data.staff_member.resigned_on} <br>
Restrict Access From ${data.staff_member.restrict_access_from}
</p>
                    </div>
                        `);
                    } else {
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-warning">
                        <strong>No Message</strong>
                    </div>
                        `);
                    }

                    if (typeof data.todays_attendances !== 'undefined') {
                        // display list
                        $('#attendance_list_group').append(`
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <strong>Attendance/Temperature for Today</strong>
                                        </li>`);

                        data.todays_attendances.forEach(function(value, i) {
                            $('#attendance_list_group').append(`
                                                     <li class="list-group-item d-flex justify-content-between align-items-center  animate__animated ${i % 2 == 0 ? 'animate__backInUp' : 'animate__backInDown'}  ${value.direction == 'in' ? '' : 'bg-out-attendance'}">
                                            <span class="text-uppercase text-lg"> ${value.direction}</span>

<div class="btn-group">
                        <button type="button" class="btn btn-sm  btn-primary">${value.hour}:${value.minutes}</button>
                        <button type="button" class="btn btn-sm  text-white bg-${value.temperature > 36.9 ? 'danger' : 'success'}">${value.temperature} °c</button>
                        </div>
                                        </li>
                                                    `);
                        });
                    }


                })
                .catch(err => console.error(err));

        }

        function updateStats() {
            $('#in_counter').html(in_count);
            $('#out_counter').html(out_count);
            $('#on_prem_counter').html(in_count - out_count);
        }

        function submitForm(direction) {
            {{-- event.preventDefault(); --}}
            console.log(direction);
            {{-- $('mark_attendance_buttons').attr("class", "btn btn-block btn-danger disabled"); --}}
            $('.mark_attendance_buttons').attr("disabled", "disabled");
            var formData = new FormData(document.getElementById('attendance_form'));
            formData.append("direction", direction);
            fetch('{{ route('mark_attendance') }}', {
                    method: 'POST',
                    body: formData
                })
                .then(
                    response => response.json())
                .then(function(data) {
                    console.log(data);
                    if (data.attendance_entered == true) {
                        // show notification for such
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-success">
                        <strong>Attendance Marked</strong>
                    </div>
                        `);

                        $('#temperature_field').val('');
                        $('#temperature').hide();

                        $('#in_counter').html(data.stats.ins);
                        $('#out_counter').html(data.stats.outs);
                        $('#on_prem_counter').html(data.stats.on_prem);
                    } else if (data.msg !== 'undefined') {
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-warning">
                        <strong>Attendance Not Marked</strong>
<p>${data.msg}</p>
                    </div>
                        `);
                    } else if (data.staff_member.restrict_access_from != null) {
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-danger">
                        <strong>Attendance Not Marked</strong>
<p>${surname} ${data.staff_member.other_names} <br>
Resigned at: ${data.staff_member.resigned_on} <br>
Restrict Access From ${data.staff_member.restrict_access_from}
</p>
                    </div>
                        `);
                    } else {
                        $('#staff_details').append(`
                        <div class="pb-0 alert alert-dismissible alert-warning">
                        <strong>Attendance Not Marked</strong>
<p>${data.msg}</p>
                    </div>
                        `);
                    }

                    if (typeof data.nows_attendance !== 'undefined') {
                        // display list
                        if (data.nows_attendance.direction == 'in') {
                            in_count++;
                        } else {
                            out_count++;
                        }

                        updateStats();

                        // data.todays_attendances.forEach(function (value, i) {
                        $('#attendance_list_group').append(`
                                                     <li class="list-group-item d-flex justify-content-between align-items-center  animate__animated  ${data.nows_attendance.direction == 'in' ? 'animate__backInDown' : 'animate__backInUp bg-out-attendance'}">
                                            <span class="text-uppercase text-lg"> ${data.nows_attendance.direction}</span>

<div class="btn-group">
                        <button type="button" class="btn btn-sm  btn-primary">${data.nows_attendance.hour}:${data.nows_attendance.minutes}</button>
                        <button type="button" class="btn btn-sm  text-white bg-${data.nows_attendance.temperature > 36.9 ? 'danger' : 'success'}">${data.nows_attendance.temperature} °c</button>
                        </div>
                                        </li>
                                                    `);
                        // });
                    }

                })
                .catch(err => console.error(err));
        }

        document.getElementById("attendance_button_in").addEventListener("click", submitForm('in'));
        document.getElementById("attendance_button_out").addEventListener("click", submitForm('out'));
        document.getElementById("attendance_form").addEventListener("submit", submitForm);
        document.getElementById("check_staff_info").addEventListener("submit", checkStaffInfo);
    </script>
@endpush
