@extends('frontend.layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                @include('frontend.business_goals.parts._business-area-selector')
                <div class="card">
{{--                    {{ dd($business_area) }}--}}

                    <div class="card-header">{{ $business_area->name ?? 'Yyyy?'}} - Business Score Card Data Entry for Wk {{ $selected_week->week_number }}: {{ $selected_week->from_day }} - {{ $selected_week->to_day }}</div>
                    <div class="card-body">
                        <form action="{{ route('frontend.business_goals.store_report') }}" method="POST">
                            @csrf
                            <input type="hidden" name="business_area_id" value="{{ $business_area->id }}">
{{--                            <div class="form-group mb-3">--}}
{{--                                <label for="">For Date</label>--}}
{{--                                <input type="date" name="for_date" max="" id="" class="form-control" placeholder=""--}}
{{--                                       aria-describedby="helpId">--}}
{{--                                <span class="text-muted">Fill this if the report is just for a day</span>--}}
{{--                            </div>--}}

                            <div class="form-group mb-3" style="display: none;">
                                <label for="">Week</label>
                                <select type="date" name="week_range_id" id="" class="form-control" readonly>
                                    @include('frontend.business_goals.parts._week_range_options', ['selected_week_id' => isset($week_range_id) ? $week_range_id : null])
                                </select>
{{--                                <span class="text-muted">Or select a week</span>--}}
                            </div>

                            @if(in_array($business_area->id, [2, 3, 6, 7]))
                            @if($business_area->id == 2)

@php
// For Ground Ops ordering
    $custom_order = [73, 75, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 89, 90, 186, 187, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 188, 110];
@endphp
                                @elseif($business_area->id == 3)
                                    @php
                                        // For Flight Ops - Operational Delivery / Customer Service ordering
                                            $custom_order = [1, 2, 27, 28, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15
];
                                          $fl_ops_target = [
                                              '1' => 80,
                                              '3' => 90,
                                              '27' => 85,
                                              '14' => 96
];
                                    @endphp

                                @elseif($business_area->id == 7)
                                @php
                                $custom_order = [111, 112, 162, 113, 114, 115];
                                @endphp

                                @elseif($business_area->id == 6)
{{--                                    59 - Flight completion , 60 - Cancelation , 61 - OTP , 62 - No. of Flights operated , 63 - No. of Flights Scheduled , 64 - Chartered Flight , 65 - Seat factor , 66 - PAX , 67 - Capacity , 68 - Available Aircraft , 69 - Flown Aircraft , 70 - Utilization , 71 - AOG , 72 - Additional flight ,--}}
                                    @php

                                $custom_order = [59, 60, 61, 62, 63, 64, 65, 66, 67, 72, 68, 69, 70, 71];
                                @endphp
                                @endif

                            @foreach($custom_order as $order)
                                @php $form_field = $form_fields->where('id', $order)->first(); $field_value = null; @endphp
								@if($form_field)
                                @isset($data_points) @php $field_value = $data_points->where('business_area_id', $business_area->id)->where('score_card_form_field_id', $form_field->id)->where('week_range_id', $week_range_id)->first() @endphp @endisset
                                <div class="form-group">
                                    <label>{{ $form_field->label }} @if(isset($form_field->unit) && $form_field->unit != '') ({{ $form_field->unit }}) @endisset</label>
                                    <input name="form_field[{{ $form_field->id }}]" id="f_id_{{ $form_field->id }}" type="{{ $form_field->form_type }}" @if($form_field->form_type == 'number') step="0.01" min="0" @endif placeholder="{{ $form_field->placeholder }}" class="form-control" value="{{ (isset($fl_ops_target) && isset($fl_ops_target[$form_field->id] )) ? $fl_ops_target[$form_field->id] : (isset($field_value) ? $field_value->data_value : '') }}" @isset($field_value) required @endisset>
                                </div>
								@endif
                            @endforeach

                                @if($business_area->id == 7)
                                    @include('frontend.business_goals.parts._commercial-customer-relations-data-entry')
                                @endif


                            @else
                                @foreach($form_fields as $form_field)
                                    @php $field_value = null; @endphp
                                    @isset($data_points) @php $field_value = $data_points->where('business_area_id', $business_area->id)->where('score_card_form_field_id', $form_field->id)->where('week_range_id', $week_range_id)->first() @endphp @endisset
                                    <div class="form-group">
                                        <label>{{ $form_field->label }} @isset($form_field->unit) ({{ $form_field->unit }}) @endisset</label>
                                        <input name="form_field[{{ $form_field->id }}]" type="{{ $form_field->form_type }}" @if($form_field->form_type == 'number') step="0.01" min="0" @endif placeholder="{{ $form_field->placeholder }}" id="f_id_{{ $form_field->id }}" class="form-control @if(in_array($form_field->id, [29, 32, 33, 34])) hr_staff_categories @endif" @isset($field_value) value="{{ $field_value->data_value }}" required @endisset>
                                    </div>
                                @endforeach
                            @endif

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('after-scripts')
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            @if($business_area->id == 1)
            var headcount = document.getElementById('f_id_16');
            // console.log(headcount);
            headcount.value = 0;
            const inputFields = document.querySelectorAll('.hr_staff_categories');

            var sum_headcount = 0;
            inputFields.forEach(function (inputField) {
                inputField.addEventListener('change', handleChange);
            });

            function handleChange(event) {
                // const id = event.target.id;
                // const value = event.target.value;
                sum_headcount = 0;
                inputFields.forEach(function (hr_field) {
                    sum_headcount += Number(hr_field.value);
                });
                headcount.value = sum_headcount;
            }
            @endif
        });
    </script>
@endpush
