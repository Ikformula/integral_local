<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormAccess extends Model
{
    //
}
