{{-- Finance - Business Management --}}
@include('frontend.business_goals.dailies._table')
