{{--Revenue Management--}}
@include('frontend.business_goals.parts.table2xlsx_button', ['table_id' => 'ba_'. $business_area_id] )
<table class="table table-hover table-sm" id="ba_{{ $business_area_id }}">
    <thead>
    <tr>
        <th colspan="4" class="bg-navy">{{ $business_area->name }} Report</th>
    </tr>
    <tr>
        <th colspan="4" class="bg-navy">Weekly Analysis Flown Pax Report - Wk {{ $week_in_focus->week_number }} ({{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }})</th>
    </tr>
    <tr>
        <th>Week-on-Week</th>
        <th>Wk {{ $week_in_focus->week_number }} <small>({{ $week_in_focus->from_day }} - {{ $week_in_focus->to_day }})</small></th>
        <th>Previous Wk ({{ $week_in_focus->week_number - 1 }})<small>({{ $presentation_data['titles']['last week'] }})</small></th>
        <th>Variance</th>
    </tr>
    </thead>
    <tbody>
    @php
        $current_week_total = $prev_week_total = 0;
    @endphp

    @foreach($form_fields as $field)
        @php
        $current_week = isset($presentation_data['current_week'][$field->id]) ? $presentation_data['current_week'][$field->id]['total'] : null;
        $prev_week = isset($presentation_data['previous_week'][$field->id]) ? $presentation_data['previous_week'][$field->id]['total'] : null;
        $variance = isset($current_week) && isset($prev_week) ? round((($current_week - $prev_week) / $current_week) * 100, 2).'%' : 'N/A';
        $current_week_total += ($field->form_type == 'number' && isset($current_week)) ? $current_week : 0;
        $prev_week_total += ($field->form_type == 'number' && isset($prev_week)) ? $prev_week : 0;
    @endphp
    <tr>
        <td @if($field->id == 210) class="bg-success" @endif>{{ $field->label }}</td>
        <td>{{ isset($field->unit, $current_week) && $field->unit == '₦' ? '₦' : ''}}{{ number_format($current_week) ?? 'N/A'}}{{ isset($field->unit, $current_week) && $field->unit != '₦' ? $field->unit : ''}}</td>
        <td>{{ isset($field->unit, $prev_week) && $field->unit == '₦' ? '₦' : ''}}{{ number_format($prev_week) ?? 'N/A'}}{{ isset($field->unit, $prev_week) && $field->unit != '₦' ? $field->unit : ''}}</td>
        <td @if($variance < 0)  style="color: #DF356F" @endif>{{ $variance}}</td>
    </tr>
        @if($field->id == 58)
{{--            Adding last minute cancellations --}}
        <tr>
            <td colspan="4" align="center" class="bg-secondary">Last Minutes Cancellations/ No Show Stat vis a  vis Overbooking Performance Analysis </td>
        </tr>
        @endif
@endforeach
    </tbody>
</table>
