<?php

namespace App\Http\Controllers\Frontend\User;

use App\Http\Controllers\Controller;
use App\Models\EcsClient;
use App\Models\EcsClientAccountSummary;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\EcsClientTransactionsTrait;

class EcsExternalClientController extends Controller
{
    use EcsClientTransactionsTrait;
    public function index()
    {
        //
    }

    public function accountSummaries(Request $request)
    {
        $user_id = auth()->id();
        $user = auth()->user();
        $client_user = $user->isEcsClient;
        if(!$client_user)
            return 'No client account found. Contact Arik Air Commercial team';
        $client = $client_user->client;

        $earliest_summary = EcsClientAccountSummary::where('client_id', $client->id)->orderBy('created_at', 'ASC')->first();
        $earliest_date = $earliest_summary->created_at;

        if($request->filled('from_date')){
            $validated = $request->validate([
                'from_date' => ['before:today']
            ]);
            $from_date_temp = Carbon::createFromFormat('Y-m-d', $request->from_date)->startOfDay();
        } else {
            $from_date_temp = $earliest_date;
        }

        if($request->filled('to_date')){
            $validated = $request->validate([
                'to_date' => ['before:tomorrow', 'after:from_date']
            ]);
            $to_date_temp = Carbon::createFromFormat('Y-m-d', $request->to_date)->startOfDay();
        } else {
            $to_date_temp = Carbon::today();
        }

        $from_date = $from_date_temp->copy();
        $to_date = $to_date_temp->copy();
        $query = EcsClientAccountSummary::query()
            ->where('client_id', $client->id)
            ->whereBetween('created_at', [$from_date_temp, $to_date_temp]);

        $filterSwitch = $request->input('filterSwitch', 'allStatusesSwitch');
        if($filterSwitch !== 'allStatusesSwitch') {
            if ($filterSwitch === 'disputeSwitch') {
                $query->whereNotNull('client_disputed_at');
            } elseif ($filterSwitch === 'approvedSwitch') {
                $query->whereNotNull('client_approved_at');
            } elseif ($filterSwitch === 'unattendedSwitch') {
                $query->whereNull('client_approved_at')->whereNull('client_disputed_at');
            }
        }

        $items = $query->orderBy('created_at', 'DESC')->get();

        return view('frontend.ecs_external.account_summaries')->with([
            'items' => $items,
            'from_date' => $from_date,
            'to_date' => $to_date,
            'params' => $request->query(),
            'earliest_date' => $earliest_date,
            'client' => $client
        ]);

    }

    public function approveTrx(EcsClientAccountSummary $ecs_summary)
    {
        $ecs_summary->client_disputed_at = null;
        $ecs_summary->client_approved_at = now();
        $ecs_summary->approver_client_user_id = auth()->id();
        $client = $ecs_summary->client_idRelation;
        $client->approved_balance += $ecs_summary->credit_amount;
        $client->approved_balance -= $ecs_summary->debit_amount;
        $client->save();
        $ecs_summary->save();

        return redirect()->back()->withFlashSuccess('Transaction Approved');
    }

    public function disputeTrx(Request $request, EcsClientAccountSummary $ecs_summary)
    {
        if($request->filled('fresh_dispute')) {
            $ecs_summary->client_disputed_at = now();
            $ecs_summary->disputer_client_user_id = auth()->id();
            $ecs_summary->save();
        }

        // Store message
        $msg = $request->message;
        $msg_sent_status = $this->addDisputeMessage($ecs_summary, $msg);

        return redirect()->back()->withFlashSuccess('Transaction dispute updated');
    }

}
